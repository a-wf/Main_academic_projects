#pragma once
#include "Joueur.hpp"
#include "Animation.hpp"


using namespace std;

class Collision {
	public:
	 Animation anim;
	 void gravite (Joueur* j,int y,int x);
	 bool hors_limite (Joueur* j,int lim_gauche,int lim_droite,int lim_bas);
};
