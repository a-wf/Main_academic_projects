#pragma once
#include <SFML/Graphics.hpp>
#include "Pers.hpp"
#include "Action_tire.hpp"
#define L_MISSILE 135


class Tireur : public Pers,  public Action_tire{
	
public :
	//[nombre de ligne : 1]constructeur
	Tireur(int distancetire, const P_name& name1, const Centre& centre1,  int h_taille1, int l_taille1): 
				Pers(name1, centre1, h_taille1, l_taille1), Action_tire(distancetire) {  name = name1;  centre = centre1; }

	/*
	* 	methode virtual, car les constructeur des missiles sont different selon empire ou rebel
	*	Attaque normal d'un tireur, tirer des laser, a chaque appel increment la liste des missiles
	* 	il n'y a pas d'argument Pers adversaire car les degat sont gerer par la classe missile
	*/
	virtual void action_atq_n() = 0; 
	
	//[NdL : 1]  destructeur 
	~Tireur(){}
};
