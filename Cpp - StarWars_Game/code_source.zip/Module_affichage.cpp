#include "Modules_affichage.hpp"



Modules_affichage::Modules_affichage(){
	charge_image_choixNBJ();
	charge_image_choixC();
	charge_image_perso();
	charge_text1();
}

void Modules_affichage::game_over(sf::RenderWindow& window,std::string s) {
	if (!font.loadFromFile("graphiques/Personnage_jeu/DISTGRG_.ttf")) {
		std::cout << "Erreur de chargement de font" << endl;
	}
	fin_jeu.setFont(font);
	fin_jeu.setCharacterSize(60);
	fin_jeu.setString(s);
	fin_jeu.setColor(sf::Color::White);
	fin_jeu.setPosition(200,319);
	window.draw(fin_jeu);
}


void Modules_affichage::init_texte() {
	if (!font.loadFromFile("graphiques/Personnage_jeu/DISTGRG_.ttf")) {
		std::cout << "Erreur de chargement de font" << endl;
	}
	vie_j1.setFont(font);
	vie_j2.setFont(font);
	degat1.setFont(font);
	degat2.setFont(font);
	degat1.setCharacterSize(30);
	degat2.setCharacterSize(30);
	vie_j1.setCharacterSize(30);
	vie_j2.setCharacterSize(30);
	vie_j1.setString("Joueur 1");
	vie_j2.setString("Joueur 2");
	degat1.setString("0 percent");
	degat2.setString("0 percent");
	degat1.setColor(sf::Color::White);
	degat2.setColor(sf::Color::White);
	vie_j1.setColor(sf::Color::White);
	vie_j2.setColor(sf::Color::White);
	vie_j1.setPosition(800,20);
	vie_j2.setPosition(20,20);
	degat1.setPosition(800,80);
	degat2.setPosition(20,80);
	
}

void Modules_affichage::update_degat (int d1,int d2) {
	std :: stringstream stream;
	std :: stringstream stream2;
	stream << d1<< "  percent";
	degat1.setString(stream.str());
	stream2<< d2 << "  percent";
	degat2.setString(stream2.str());
}

void Modules_affichage::affiche_text(sf::RenderWindow& window) {
	window.draw(vie_j2);
	window.draw(vie_j1);
	window.draw(degat1);
	window.draw(degat2);
}

void Modules_affichage::charge_image_choixNBJ(){
	if (!texture1.loadFromFile("graphiques/joueurs_choix.png"))
	{
		std::cout << "Erreur durant le chargement de l'image de choixNBJ." << std::endl;
	}
	else{
		texture1.setSmooth(true);
		choix_nb_j.setTexture(texture1);
		choix_nb_j.setScale(1.5,1.5);
		choix_nb_j.setPosition(1064/2-(choix_nb_j.getTexture()->getSize().x*1.5/2),550.0);
	}
}

void Modules_affichage::charge_image_choixC(){
	if (!texture2.loadFromFile("graphiques/choix_coter.png")){
		std::cout << "Erreur durant le chargement de l'image de choixC." << std::endl;
	}
	else{
		choix_cot.setTexture(texture2);
	}
	if (!t_bL.loadFromFile("graphiques/choixPL.png")){
		std::cout << "Erreur durant le chargement de l'image de backgroundL." << std::endl;
	}
	else{
		s_bL.setTexture(t_bL);
	}
	if (!t_bO.loadFromFile("graphiques/choiPO.jpg")){
		std::cout << "Erreur durant le chargement de l'image de backgroundO." << std::endl;
	}
	else{
		s_bO.setTexture(t_bO);
	}
}

void Modules_affichage::charge_image_perso(){
	if (!t_p1.loadFromFile("graphiques/Album_Yoda.png")){
		std::cout << "Erreur durant le chargement de l'image de p1." << std::endl;}
	else{ 
		s_p1.setTexture(t_p1);
		s_p1.setPosition(1064/2-266-t_p1.getSize().x,425.0+15);
	}
	if (!t_p2.loadFromFile("graphiques/Han_Solo.png")){
		std::cout << "Erreur durant le chargement de l'image de p2." << std::endl;}
	else{ 
		s_p2.setTexture(t_p2);
		s_p2.setPosition(1064/2+266,425.0);
	}
	if (!t_p3.loadFromFile("graphiques/Album_Darth_Vader.png")){
		std::cout << "Erreur durant le chargement de l'image de p3." << std::endl;}
	else{ 
		s_p3.setTexture(t_p3);
		s_p3.setPosition(1064/2-266-t_p3.getSize().x,425.0);
	}
	if (!t_p4.loadFromFile("graphiques/Album_Boba_Fett.png")){
		std::cout << "Erreur durant le chargement de l'image de p4." << std::endl;}
	else{ 
		s_p4.setTexture(t_p4);
		s_p4.setPosition(1064/2+266,425.0);
	}
}

void Modules_affichage::charge_text1(){
	if (!t_text1.loadFromFile("graphiques/text1.png")){
		std::cout << "Erreur durant le chargement de l'image de text1." << std::endl;
	}
	else{
		s_tx1.setTexture(t_text1);
		s_tx1.setTextureRect(sf::IntRect(0,0,t_text1.getSize().x,t_text1.getSize().y/4));
		s_tx1.setPosition(1064/2-(t_text1.getSize().x/2),10);
		s_tx2.setTexture(t_text1);
		s_tx2.setTextureRect(sf::IntRect(0,t_text1.getSize().y/4,t_text1.getSize().x,t_text1.getSize().y/4));
		s_tx2.setPosition(1064/2-(t_text1.getSize().x/2),10);
		s_tx3.setTexture(t_text1);
		s_tx3.setTextureRect(sf::IntRect(0,t_text1.getSize().y*2/4,t_text1.getSize().x,t_text1.getSize().y/4));
		s_tx3.setPosition(1064/2-(t_text1.getSize().x/2),10);
		s_tx4.setTexture(t_text1);
		s_tx4.setTextureRect(sf::IntRect(0,t_text1.getSize().y*3/4,t_text1.getSize().x,t_text1.getSize().y/4));
		s_tx4.setPosition(1064/2-(t_text1.getSize().x/2),10);
	}
}


//a enlever
/*
void Modules_affichage::draw_pers(module_name choix,  sf::RenderWindow& window,Centre centre) {
	switch (choix) {
		case choixP1 :		s_p1.setPosition(centre.get_x(),centre.get_y());
							window.draw(s_p1);
							break; 
		case choixP2 :		s_p2.setPosition(centre.get_x(),centre.get_y());
							window.draw(s_p2);
							break; 
		case choixP3 :		s_p3.setPosition(centre.get_x(),(centre.get_y()));
							window.draw(s_p3);
							break; 
		case choixP4 :		s_p4.setPosition(centre.get_x(),(centre.get_y()));
							window.draw(s_p4);
							break;
		default :           break;		
	}
}*/

void Modules_affichage::draw(module_name choix,  sf::RenderWindow& window){
	switch (choix) {
		case choixC : 		window.draw(choix_cot);
							break; 
		case choixNBJ : 	window.draw(choix_nb_j);
							break; 
		case choixP1 :		window.draw(s_p1);
							break; 
		case choixP2 :		window.draw(s_p2);
							break; 
		case choixP3 :		window.draw(s_p3);
							break; 
		case choixP4 :		window.draw(s_p4);
							break; 
		case backgroundL :	window.draw(s_bL);
							break;
		case backgroundO :	window.draw(s_bO);
							break;
		case tx1 :			window.draw(s_tx1);
							break;
		case tx2 :			window.draw(s_tx2);
							break;
		case tx3 :			window.draw(s_tx3);
							break;
		case tx4 :			window.draw(s_tx4);
							break;				
		default :           break;		
	}
}

sf::Sprite Modules_affichage::get_module(module_name choix)const{
	switch (choix) {
		case choixC : 		return choix_cot;
							break; 
		case choixNBJ : 	return choix_nb_j;
							break; 		
		case choixP1 :		return s_p1;
							break; 
		case choixP2 :		return s_p2;
							break; 
		case choixP3 :		return s_p3;
							break; 
		case choixP4 :		return s_p4;
							break;  
		case backgroundL :	return s_bL;
							break;
		case backgroundO :	return s_bO;
							break;
		case tx1 :			return s_tx1;
							break;
		case tx2 :			return s_tx2;
							break;
		case tx3 :			return s_tx3;
							break;
		case tx4 :			return s_tx4;
							break;					
		default :           break;		
	}
}
