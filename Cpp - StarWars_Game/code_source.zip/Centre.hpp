
#pragma once
#include <iostream>
using namespace std;
class Centre{

private :
	
	float x;
	float y;

public :
	//[nombre de ligne : 2]construct par default
	Centre(){
		x = 0;
		y = 0;
	}

	//[NdL : 1] constructeur avec comme arguments les coordonnées x et y 
	Centre (float x1, float y1): x(x1), y(y1){}

	//[NdL : 2] constructeur avec comme arguments un type Centre
	Centre(const Centre& cen): x(cen.get_x()), y(cen.get_y()){}

	//[NdL : 1] les getteurs
	float get_x()const {return x;}
	float get_y()const{return y;}
	void set_x (float x1){ x = x1;}
	void set_y (float y1){ y = y1;}

	/*
	* [NdL : 2]surcharge d'opérateur "+ type centre" 
	* retour : Centre 
	*/
	 Centre operator+ ( const Centre& c2);
	/*
	* [NdL : 2]surcharge d'opérateur "- type centre" 
	* retour : Centre 
	*/
	 Centre operator- ( const Centre& c2);
	/*
	* [NdL : 2]surcharge d'opérateur "* type centre" 
	* retour : Centre 
	*/
	 Centre operator* ( const Centre& c2);
	/*
	* [NdL : 2]surcharge d'opérateur "/ type centre" 
	* retour : Centre 
	*/
	 Centre operator/ ( const Centre& c2);
	/*
	* [NdL : 2]surcharge d'opérateur "+ type float" 
	* retour : Centre 
	*/
	 Centre operator+ ( float r);
	/*
	* [NdL : 2]surcharge d'opérateur "- type float" 
	* retour : Centre 
	*/
	 Centre operator- ( float r);
	/*
	* [NdL : 2]surcharge d'opérateur "* type float" 
	* retour : Centre 
	*/
	 Centre operator* ( float r);
	/*
	* [NdL : 2]surcharge d'opérateur "/ type float" 
	* retour : Centre 
	*/
	 Centre operator/ ( float r);
};
