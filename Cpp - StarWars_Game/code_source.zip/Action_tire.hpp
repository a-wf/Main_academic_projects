#pragma once
#include <list>
#include "Pers.hpp"
#include "Missile.hpp"
#define MUNITION 6


class Action_tire {  
public : 
	//[nombre de ligne : 1] constructeur avec argument une distance pour la distance limite
	Action_tire(int distance):distance_tire(distance){};
	
	bool get_stock_munition()const { return munition;}
	int get_distance_tire()const {return distance_tire;}
	list<Missile> get_list_m_tirer() const { return list_m_tirer;}
	/*
	* [NdL : 5] gestion des munitions  
	* si le nombre de missile tirés est égal à MUNITION 
	* alors le booleen devien true, sinon  false
	*/
	void set_stock_munition();
	
	/*
	* [NdL : 7] gestion des missiles
	* parametre : un type Pers 
	* retour : rien 
	* gerer le deplacement des missiles tirés et le degat subi par l'adversaire si toucher par un missile
	*/
	void gestion_missile_tirer(Pers& p1);
	
protected :

	bool munition; 		//pour limiter les tires
	int distance_tire; 	//à une certaine distance, les missiles tirés disparaissent
	
	list<Missile> list_m_tirer;	//la liste des missiles tirés
	
	/*
	* [NdL : 13] si le missile touche l'adversaire
	* l'adversaire subi des degats et le missile disparait
	* retour : true ou false, pour savoir si la methode a bien fonctionner ou pas
	*/
	bool missile_touche_advers(Pers& p1, Missile& m,list<Missile>::iterator& iter);
	
	/*
	* [NdL : 25] si le missile ne touche pas l'adversaire et que le missile est dans l'interval autorisé
	* le missile se deplace parallele au sol
	*/
	void missile_continue_trajet(Missile& m,list<Missile>::iterator& iter);
};
