#include "Horloge.hpp"


Horloge::Horloge(bool initHorlg) : buf(sf::Time::Zero), run(initHorlg){}
 
Horloge::~Horloge(){}
 
sf::Time Horloge::getElapsedTime() const{
    if(run)
        return (buf + clock.getElapsedTime());
    return buf;
}
 
bool Horloge::isRunning() const{  return run; }
 
void Horloge::start(){
    if(!run){
        run = true;
        clock.restart();
    }
}
 
void Horloge::stop(){
    if(run)
    {
       // On ajoute dans le buffer le temps écoulé
        buf += clock.getElapsedTime();
        run = false;
    }
}
 
void Horloge::restart(bool still_r){
    buf = sf::Time::Zero;
    run = still_r;
    clock.restart();
}