#pragma once
#include <iostream>
#include <SFML/Graphics.hpp>
#include "Centre.hpp"
#include <string>
#include <sstream> 

//idenficateur des modules d'affichage choix des joueurs
enum module_name { choixC=1, choixNBJ, choixP1, choixP2, choixP3, choixP4, backgroundL, backgroundO, tx1, tx2, tx3,tx4};
class Modules_affichage
{
	public:
	//[nombre de ligne : 4] constructeur par defaut qui fait les chargements des sprites
	Modules_affichage();
	
	/*[NdL : 27]
	* dessine sur la fenetre l'un des modules sprites selon l'idenficateur "choix" de type "module_name"
	*/
	void draw(module_name choix,  sf::RenderWindow& window);
	
	/*[NdL : 27]
	* renvoie l'un des modules spritees selon l'idenficateur "choix" de type "module_name"
	*/
	sf::Sprite get_module(module_name choix)const;
	
	void affiche_text(sf::RenderWindow& window);
	
	void update_degat (int d1,int d2);
	
	void init_texte();
	
	void game_over(sf::RenderWindow& window,std::string s);
	
	//void draw_pers(module_name choix,  sf::RenderWindow& window,Centre centre);//ne sert pas dans le jeu

	private:
	// les textures 
	sf::Texture texture1; 	//texture d'image pour choix des joueurs
	sf::Texture texture2;	//texture pour choix du coter
	sf::Texture t_bL;		//texture pour coter lumiere Rebel
	sf::Texture t_bO;		//texture pour coter obscure Empire
	sf::Texture t_p1;		//texture pour image personnage yoda
	sf::Texture t_p2;		//texture pour image personnage han solo
	sf::Texture t_p3;		//texture pour image personnage dark vador
	sf::Texture t_p4;		//texture pour image personnage boba fett
	sf::Texture t_text1;	//texture pour image des texts des choix
	
	//  les sprites
	sf::Sprite choix_nb_j;	//sprites d'image pour choix des joueurs
																			//sf::Sprite choix_pers;	//sert a quoi ????
	sf::Sprite choix_cot;	//sprites pour choix du coter
	sf::Sprite s_bL;		//sprites pour background lumiere
	sf::Sprite s_bO;		//sprites pour background obscure
	sf::Sprite s_p1;		//sprites yoda
	sf::Sprite s_p2;		//sprites han solo
	sf::Sprite s_p3;		//sprites dark vador
	sf::Sprite s_p4;		//sprites boba fett
	sf::Sprite s_tx1;		//sprites text_1
	sf::Sprite s_tx2;		//sprites text_2			
	sf::Sprite s_tx3;		//sprites text_3
	sf::Sprite s_tx4;		//sprites text_4
	
	sf::Font font;
	sf::Text vie_j1;
	sf::Text vie_j2;
	sf::Text degat1;
	sf::Text degat2;
	
	sf::Text fin_jeu;
																							
	/*[NdL : 10]
	* pour effectuer le chargement d'images pour les boutons un joueur ou deux joueurs
	*/
	void charge_image_choixNBJ();
	
	/*[NdL : 18]
	* pour effectuer le chargement des images des background de choix du coté Rebel ou Empire
	*/
	void charge_image_choixC();
	
	/*[NdL : 24]
	* pour effectuer le chargement des images des personnages pour faire les choix du personnage
	* Remarque :  ne sont pas les sprites pour l'animation des personnages dans le jeu
	*/
	void charge_image_perso();
	
	/*[NdL : 17]
	* pour effectuer le chargement des images des texts à afficher durant les choix
	*/
	void charge_text1();
};

