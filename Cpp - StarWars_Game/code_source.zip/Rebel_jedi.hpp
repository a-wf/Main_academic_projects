#pragma once 
#include "SabreL.hpp"
#include "Sprites_Jedi.hpp"

class Rebel_jedi : public SabreL {
public : 
	//les sprites de yoda,   mis en public pour faciliter l'utilisation, a mettre en private si necessaire
	Sprites_Jedi sprites_YD;
	//[nombre de ligne : 1]constructeur
	Rebel_jedi(int long_lame, const P_name& name1, const Centre& centre1, int h_taille1, int l_taille1):
		SabreL(long_lame, name1, centre1,  h_taille1, l_taille1), sprites_YD("graphiques/Personnage_jeu/yoda14.png"){sprites_YD.set_centre_sprites(centre1);}
		
	/*
	* [NdL : 11] 
	* Attaque special d'un jedi, la force invisible    
	* parametre : type Pers p1, pour repousser l'adversaire, sans degat
	*/
	void action_atq_s(Pers &p1);
	//[NdL : 2] modifier le centre du personnage et le centre des sprite du personnage
	void set_centre(Centre c){
		this->centre = c;
		sprites_YD.set_centre_sprites(c);
	}
	
	//[NdL : 1]  destructeur 
	~Rebel_jedi(){}
};
