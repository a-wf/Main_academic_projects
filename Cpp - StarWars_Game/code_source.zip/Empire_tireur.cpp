#include "Empire_tireur.hpp"


void Empire_tireur::action_atq_s(){
	/*Missile mg(Centre(centre.get_x()+l_taille/2, centre.get_y()), 100,100, 30, "missile_flamme",sprites_BB.s_misS, gauche_droite);
	list_m_tirer.push_back(mg);*/
}

void Empire_tireur::action_atq_n(){
	/*Missile m(Centre(centre.get_x()+l_taille/2, centre.get_y()), L_MISSILE,30, 10, "missile_laser", sprites_BB.s_misN, gauche_droite);
	list_m_tirer.push_back(m);*/
}
