#include "Game.hpp"
#include <SFML/Window/Keyboard.hpp>


Game::Game(): hauteur(H_Game_W), largeur(L_Game_W), window(sf::VideoMode(largeur, hauteur), "Super Smash Bros : Star Wars"), modules(), m_game(){
	m_game.set_background("graphiques/bibibisStarWars_Game.png", 1064, 638);
	//Limite les fps à 60 images / seconde
	window.setFramerateLimit(60);
	//On active la synchro verticale
	window.setVerticalSyncEnabled(true);
	window.setPosition(sf::Vector2i(0,0));
	g_display();
}


int Game::get_p_sol(Joueur * j) {
	switch (j->get_perso_name()) {
		case 	Yoda: 	   	return get_p_sol()+33;break;
		case 	DarkVador: 	return get_p_sol()+17;break;
		case 	HanSolo: 	return get_p_sol();break;
		case 	BobaFett: 	return get_p_sol();break;
		default : 			return get_p_sol();break;
	} 
}

void Game::g_display(){
	m_game.set_background("graphiques/bibibisStarWars_Game.png", 1064, 638);
	while (window.isOpen()){
		// on inspecte tous les évènements de la fenêtre qui ont été émis depuis la précédente itération
		sf::Event event;
		while (window.pollEvent(event)){
			// évènement "fermeture demandée" : on ferme la fenêtre
			if (event.type == sf::Event::Closed)
				window.close();
		}
		window.clear();
		m_game.drawBackground(window);
		if(choix_nb_joueur()==true){
			choix_map_jeu();
		}
		window.display();
	}
}
void Game::f_close(){
	sf::Event event;
		while (window.pollEvent(event)){
			// évènement "fermeture demandée" : on ferme la fenêtre
			if (event.type == sf::Event::Closed)
				window.close();
		}
	window.clear();
}
bool Game::choix_nb_joueur(){
	int i;
	modules.draw(choixNBJ, window);
	window.display();
	bool avoir_choisi = false;
	bool fin_choix = false;
	if(sf::Mouse::isButtonPressed(sf::Mouse::Left)){  //les coordonnées int ci desous, sont determiner avec la position des boutons joueurs et leur dimension
		if(sf::Mouse::getPosition(window).x<(modules.get_module(choixNBJ).getPosition().x+240)&&sf::Mouse::getPosition(window).x>modules.get_module(choixNBJ).getPosition().x
		&&sf::Mouse::getPosition(window).y<(modules.get_module(choixNBJ).getPosition().y+modules.get_module(choixNBJ).getLocalBounds().height*1.5)&& sf::Mouse::getPosition(window).y> modules.get_module(choixNBJ).getPosition().y){
			bool_nb_joueur = false; 
			//avoir_choisi = true;
			cout<<"rechoisissez, car pas possible pour l'instant de joueurseul"<<bool_nb_joueur<<endl;
		}else if(sf::Mouse::getPosition(window).x<(modules.get_module(choixNBJ).getPosition().x+modules.get_module(choixNBJ).getLocalBounds().width*1.5)&&sf::Mouse::getPosition(window).x>(modules.get_module(choixNBJ).getPosition().x+modules.get_module(choixNBJ).getLocalBounds().width*1.5-255)
			&&sf::Mouse::getPosition(window).y<(modules.get_module(choixNBJ).getPosition().y+200+modules.get_module(choixNBJ).getLocalBounds().height*1.5)&& sf::Mouse::getPosition(window).y> modules.get_module(choixNBJ).getPosition().y)
		{
			bool_nb_joueur = true;
			avoir_choisi = true;
		}
	}
	if(avoir_choisi == true){
		if(bool_nb_joueur = true){
			for(i = 0; i < 2; i++){
				while(choix_cot(i)==false&&window.isOpen()){f_close();	window.clear();}
			}
		}else{
			while(choix_cot(0)==false&&window.isOpen()){f_close();	window.clear();}
		}
		fin_choix = true;
	}
	return fin_choix;
}

bool Game::choix_cot(int i){
	modules.draw(choixC, window);
	if(i == 0)
		modules.draw(tx1, window);
	if(i == 1)
		modules.draw(tx2,window);
	bool avoir_choisi = false;
	window.display();
	if(sf::Mouse::isButtonPressed(sf::Mouse::Left)){  //les coordonnées int ci desous, sont determiner par test
		if(sf::Mouse::getPosition(window).x<369&&sf::Mouse::getPosition(window).x>90
		&&sf::Mouse::getPosition(window).y<629&& sf::Mouse::getPosition(window).y>495){
			avoir_choisi =true;
			bool_coter = false;
		}else if(sf::Mouse::getPosition(window).x<966&&sf::Mouse::getPosition(window).x>693
			&&sf::Mouse::getPosition(window).y<629&& sf::Mouse::getPosition(window).y>495){	
			avoir_choisi =true;
			bool_coter = true;
		}
	}
	if(avoir_choisi==true){
		while(choix_perso(i)==false&&window.isOpen()){f_close();	window.clear();}
	}
	return avoir_choisi;
}


bool Game::choix_perso(int i){  //carte du jeu a faire  personnages a charger
	bool avoir_choisi = false;
	if(bool_coter == false){
		fenetre_choixPL(i);
		avoir_choisi = creer_pers_selonChoixL(i);
	}else{
		fenetre_choixPO(i);
		avoir_choisi = creer_pers_selonChoixO(i);
	}
	return avoir_choisi;
}

void Game::fenetre_choixPL(int i){
	modules.draw(backgroundL, window);
	modules.draw(choixP1, window);
	modules.draw(choixP2, window);
	if(i == 0)
		modules.draw(tx3,window);
	if(i == 1)
		modules.draw(tx4,window);
	window.display();
}
void Game::fenetre_choixPO(int i){
	modules.draw(backgroundO, window);
	modules.draw(choixP3, window);
	modules.draw(choixP4, window);
	if(i == 0) 
		modules.draw(tx3,window); 
	if(i == 1)
		modules.draw(tx4,window);
	window.display();
}

bool Game::creer_pers_selonChoixL(int i){
	bool avoir_choisi = false;
	if(sf::Mouse::isButtonPressed(sf::Mouse::Left)){  //les coordonnées int ci desous, sont determiner selon les Srpites
		if(sf::Mouse::getPosition(window).x<(modules.get_module(choixP1).getPosition().x+modules.get_module(choixP1).getLocalBounds().width)&&sf::Mouse::getPosition(window).x>modules.get_module(choixP1).getPosition().x 
		&&sf::Mouse::getPosition(window).y<(modules.get_module(choixP1).getPosition().y+modules.get_module(choixP1).getLocalBounds().height)&& sf::Mouse::getPosition(window).y>modules.get_module(choixP1).getPosition().y){
			avoir_choisi =true;
			if(i ==0)
				j1 = new Joueur(Yoda,"Joueur1",false);
			if(i==1)
				j2 = new Joueur(Yoda,"Joueur2",false);
		}else if(sf::Mouse::getPosition(window).x<(modules.get_module(choixP2).getPosition().x+modules.get_module(choixP2).getLocalBounds().width)&&sf::Mouse::getPosition(window).x>modules.get_module(choixP2).getPosition().x 
		&&sf::Mouse::getPosition(window).y<(modules.get_module(choixP2).getPosition().y+modules.get_module(choixP2).getLocalBounds().height)&& sf::Mouse::getPosition(window).y>modules.get_module(choixP2).getPosition().y){
			avoir_choisi =true;
			if(i ==0)
				j1 = new Joueur(HanSolo,"Joueur1",false);
			if(i=1)
				j2 = new Joueur(HanSolo,"Joueur2",false);
		}
	}
	return avoir_choisi;
}

bool Game::creer_pers_selonChoixO(int i){
	bool avoir_choisi = false;
	if(sf::Mouse::isButtonPressed(sf::Mouse::Left)){  //les coordonnées int ci desous, sont determiner selon les Srpites
		if(sf::Mouse::getPosition(window).x<(modules.get_module(choixP3).getPosition().x+modules.get_module(choixP3).getLocalBounds().width)&&sf::Mouse::getPosition(window).x>modules.get_module(choixP3).getPosition().x 
		&&sf::Mouse::getPosition(window).y<(modules.get_module(choixP3).getPosition().y+modules.get_module(choixP3).getLocalBounds().height)&& sf::Mouse::getPosition(window).y>modules.get_module(choixP3).getPosition().y){
			avoir_choisi =true;
			if(i==0)
				j1 = new Joueur(DarkVador,"Joueur1",false);
			if(i==1)
				j2 = new Joueur(DarkVador,"Joueur2",false);
		}else if(sf::Mouse::getPosition(window).x<(modules.get_module(choixP4).getPosition().x+modules.get_module(choixP4).getLocalBounds().width)&&sf::Mouse::getPosition(window).x>modules.get_module(choixP4).getPosition().x 
		&&sf::Mouse::getPosition(window).y<(modules.get_module(choixP4).getPosition().y+modules.get_module(choixP4).getLocalBounds().height)&& sf::Mouse::getPosition(window).y>modules.get_module(choixP4).getPosition().y){
			avoir_choisi =true;
			if(i==0)
				j1 = new Joueur(BobaFett,"Joueur1",false);
			if(i==1)
				j2 = new Joueur(BobaFett,"Joueur2",false);
		}
	}
	return avoir_choisi;
}

void Game::choix_map_jeu(){
	srand(time(NULL));
	int id_map = rand()%3+1;   //mis en commentaire pour les tests
	switch(id_map){
		case 1:	
			id_enum_map = foret;
			m_game.set_background("graphiques/map_foret.png", 1064, 700);
			anim1.set_mgame(&m_game);
			anim2.set_mgame(&m_game);
			window.setSize(sf::Vector2u(1064, 700));
			set_p_sol(P_sol_foret_lava-15);
			run_game();
			break;
		case 2:
			id_enum_map = style_mario;
			m_game.set_background("graphiques/map_land.png", 1064, 700);
			anim1.set_mgame(&m_game);
			anim2.set_mgame(&m_game);
			window.setSize(sf::Vector2u(1064, 700));
			set_p_sol(p_sol_mario);
			run_game();
			break;
		case 3: 
			id_enum_map = lave;
			m_game.set_background("graphiques/map_lava.png", 1064, 700);
			anim1.set_mgame(&m_game);
			anim2.set_mgame(&m_game);
			window.setSize(sf::Vector2u(1064, 700));
			set_p_sol(P_sol_foret_lava);
			run_game();
			break;
	}
}

/*
 * Gestion des deplacement des joeurs. 
 */

void Game::gestion_j1_deplacmt() {
	bool hors_lim;
	if (j1->get_en_saut()) { // s'il est entrain d'esxcuter un saut 
			j1->sauter(get_p_sol(j1)); //continuer
			anim1.animation_deplacemt(j1, Haut);
	}
	else if (collision.hors_limite(j1,limite_g,limite_d,get_p_sol(j1))) { // si hors limite.
		// permettre de sauter si ses degats < 100.
		hors_lim = true; 
		if (get_degat_subi_j(j1) < 100) {
			if ((Keyboard::isKeyPressed(Keyboard::Up)) && j1->get_sprite().getPosition().y >= get_p_sol(j1)) {
				j1->set_saut(true);
				j1->sauter(get_p_sol(j1));
				anim2.animation_deplacemt(j1, Haut);
			}  
		}
	}
	if(appui1==true){
		if (j1->get_en_saut() || hors_lim);
		else if ((Keyboard::isKeyPressed(Keyboard::Up)) && j1->get_sprite().getPosition().y >= get_p_sol(j1)) {
			j1->set_saut(true);
			j1->sauter(get_p_sol(j1));
			anim1.animation_deplacemt(j1, Haut);
		}
		if ((Keyboard::isKeyPressed(Keyboard::Left))) {
			j1->deplacemt(Gauche);
			anim1.animation_deplacemt(j1, Gauche);
		}
		if ((Keyboard::isKeyPressed(Keyboard::Right))) {
			j1->deplacemt(Droite);
			anim1.animation_deplacemt(j1, Droite);
		}
	}else{
		anim1.anim_defaut(j1);
	}
	collision.gravite(j1,get_p_sol(j1),0);
}


void Game::gestion_j2_deplacmt() {
	bool hors_lim;
	if (j2->get_en_saut()) {
			j2->sauter(get_p_sol(j2));
			anim2.animation_deplacemt(j2, Haut);
	}
	else if (collision.hors_limite(j2,limite_g,limite_d,get_p_sol(j2))) {
		hors_lim = true;
		cout << "degat subit :" <<get_degat_subi_j(j1) << endl;
		if (get_degat_subi_j(j2) < 100) {
			if ((Keyboard::isKeyPressed(Keyboard::Z)) && j2->get_sprite().getPosition().y >= get_p_sol(j2)) {
				j2->set_saut(true);
				j2->sauter(get_p_sol(j2));
				anim2.animation_deplacemt(j2, Haut);
			}  
		}
	}
	if(appui2==true){
		if (j2->get_en_saut() || hors_lim);
		else if ((Keyboard::isKeyPressed(Keyboard::Z)) && j2->get_sprite().getPosition().y >= get_p_sol(j2)) {
			j2->set_saut(true);
			j2->sauter(get_p_sol(j2));
			anim2.animation_deplacemt(j2, Haut);
		}
		if ((Keyboard::isKeyPressed(Keyboard::Q))){
			j2->deplacemt(Gauche);
			anim2.animation_deplacemt(j2, Gauche);
		}
		if ((Keyboard::isKeyPressed(Keyboard::D))){
			j2->deplacemt(Droite);
			anim2.animation_deplacemt(j2, Droite);
		}
	}else{
		anim2.anim_defaut(j2);
	}
	collision.gravite(j2,get_p_sol(j2),0);
}

void Game::gestion_j2_sans_appuis(){
	appui2 = false;
	if (Keyboard::isKeyPressed(Keyboard::A)||Keyboard::isKeyPressed(Keyboard::E)||Keyboard::isKeyPressed(Keyboard::S)||Keyboard::isKeyPressed(Keyboard::Z)||Keyboard::isKeyPressed(Keyboard::Q)||Keyboard::isKeyPressed(Keyboard::D)) {
		appui2=true;
	}
}

void Game::gestion_j1_sans_appuis(){
	appui1 = false;
	if (Keyboard::isKeyPressed(Keyboard::B)||Keyboard::isKeyPressed(Keyboard::N)||Keyboard::isKeyPressed(Keyboard::Down)||Keyboard::isKeyPressed(Keyboard::Up)||Keyboard::isKeyPressed(Keyboard::Left)||Keyboard::isKeyPressed(Keyboard::Right)) {
		appui1=true;
	}
}

void Game::gestion_attaque_normal_j1(){
	if (Keyboard::isKeyPressed(Keyboard::B)) {
		j1->attaq_n(j2);
		anim1.animation_attq_n(j1, j2, &window);		
	}	
}


void Game::gestion_attaque_normal_j2(){
	if (Keyboard::isKeyPressed(Keyboard::A)) {
		j2->attaq_n(j1);
		anim2.animation_attq_n(j2, j1, &window);
	}
}


void Game::gestion_attaque_special_j1(){
	if (Keyboard::isKeyPressed(Keyboard::N)) {
		j1->attaq_s(j2);
		anim1.animation_attq_s(j1, j2, &window);
	}	
}

void Game::gestion_attaque_special_j2(){
	if (Keyboard::isKeyPressed(Keyboard::E)) {
		j2->attaq_s(j1);
		anim2.animation_attq_s(j2, j1, &window);
	}	
}

void Game::affiche_perso(Joueur* j) {
	window.draw(j->get_sprite());
}

void Game::gestion_missile(){
	switch(j1->get_perso_name()){
		case HanSolo: 	j1->hs_gestion_missile(j2); break;
		case BobaFett: 	j1->bf_gestion_missile(j2); break;
		default : break;
	}
	switch(j2->get_perso_name()){
		case HanSolo: 	j2->hs_gestion_missile(j2); break;
		case BobaFett: 	j2->bf_gestion_missile(j1); break;
		default : break;
	}
	anim1.anim_missile(j1, &window);
	anim2.anim_missile(j1, &window);
	
}

void Game::run_game(){
	modules.init_texte();
	while (window.isOpen()) {
		// on inspecte tous les évènements de la fenêtre qui ont été émis depuis la précédente itération
		sf::Event event;
		while (window.pollEvent(event)){
			// évènement "fermeture demandée" : on ferme la fenêtre
			if (event.type == sf::Event::Closed)
				window.close();
		}
		gestion_priorite_joueur ();
		gagner_perdu();
		window.clear();
		m_game.drawBackground(window);
		affiche_perso(j1);
		affiche_perso(j2);
		modules.affiche_text(window);
		modules.update_degat(get_degat_subi_j(j1),get_degat_subi_j(j2));
		window.display();
	}
}


int Game::get_degat_subi_j(Joueur* j){
	switch (j->get_perso_name()){
		case Yoda: 		return j->get_yoda()->get_degatsubi();
						break;
		case DarkVador: return j->get_dark()->get_degatsubi();
						break;
		case HanSolo: 	return j->get_hanS()->get_degatsubi();
						break;
		case BobaFett: 	return j->get_boba()->get_degatsubi();
						break;
	}
}

void Game::gagner_perdu(){
	if(g_p_j(j1)){
		module_fin.game_over(window,"joueur 2 a gagne");
		window.display();
		usleep(3000000);
		recommencer_partie();
	}
	else if(g_p_j(j2)){
		module_fin.game_over(window,"joueur 1 a gagne");
		window.display();
		usleep(3000000);
		recommencer_partie();
	}
}

bool Game::g_p_j(Joueur* j){
	switch (j->get_perso_name()){
		case Yoda: 		if(j->get_yoda()->get_centre().get_y()> get_p_sol(j1)+200)  return true;
						break;
		case DarkVador: if(j->get_dark()->get_centre().get_y()> get_p_sol(j1)+200)  return true;
						break;
		case HanSolo: 	if(j->get_hanS()->get_centre().get_y()> get_p_sol(j1)+200)  return true;
						break;
		case BobaFett: 	if(j->get_boba()->get_centre().get_y()> get_p_sol(j1)+200)  return	true;
						break;
	}
}

void Game::gestion_priorite_joueur () {
	srand(time(NULL));
	int j = rand()%2+1;
	if (j == 1) {
		gestion_j1_deplacmt();
		gestion_j1_sans_appuis();
		gestion_attaque_normal_j1();
		gestion_attaque_special_j1();
		gestion_j2_sans_appuis();
		gestion_j2_deplacmt();
		gestion_attaque_normal_j2();
		gestion_attaque_special_j2();
	}
	if (j == 2) {
		gestion_j2_sans_appuis();
		gestion_j2_deplacmt();
		gestion_attaque_normal_j2();
		gestion_attaque_special_j2();
		gestion_j1_deplacmt();
		gestion_j1_sans_appuis();
		gestion_attaque_normal_j1();
		gestion_attaque_special_j1();
	}
}


void Game::recommencer_partie(){
	g_display();
}
