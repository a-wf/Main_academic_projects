#pragma once 
#include <iostream>
#include <SFML/Graphics.hpp>

class Horloge
{
    public:
        /* [nombre de ligne : 1]
        *  Horloge constructor
        */
        Horloge(bool initHorlg = false);
 
        /*[NdL : 1]
        *  Virtual default destructor
        */
        virtual ~Horloge();
 
        /*[NdL : 3]
        *  Return the elapsed time since the start or last reset
        * return Elapsed time
        */
        sf::Time getElapsedTime() const;
 
        /*[NdL : 1]
        *  Is the Horloge running ?
        *  true if it's running
        */
        bool isRunning() const;
 
        /*[NdL : 4]
        *  Start the Horloge
        */
        void start();
 
        /*[NdL : 5]
        *  Stop the Horloge
        */
        void stop();
 
        /*[NdL : 3]
        *  Reset the Horloge
        *  still_r If true, the Horloge will keep running, by default it stops !
        */
        void restart(bool still_r = false);
 
    private:
        sf::Clock   clock;
        sf::Time    buf;
        bool        run;
};
