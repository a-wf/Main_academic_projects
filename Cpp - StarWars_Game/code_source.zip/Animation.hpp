#pragma once
#include <iostream>
#include <SFML/Graphics.hpp>
#include "Horloge.hpp"
#include "Missile.hpp"
#include "Joueur.hpp"
#include "Mapp.hpp"
//#include <unistd.h>

class Animation {
	private :
	bool gauche_droite = false;		//pour savoir si le personnage est orienter vers la gauche ou la droite
	Horloge clock;				//timer 
	Mapp *m_game;
	/*float   time1 = 0.0;			//un "record" timer
	float   time2 = 0.0;*/			//un "record" timer
	
	/*
	* un compteur d'animation, on utilise soit un compteur pour les animations soit un timer,
	* pour l'instant on utilise le compteur, car les algorithms du timer de fontionnent pas encore
	*/
	int compt = 0;					 
	
	public :
	
	/*[NdL : 1]
	* set map game
	*/
	void set_mgame(Mapp* m){m_game = m;}
	
	/*
	Animation(): time1(0.0), time2(0.0){
		clock.stop();
	}
	
	void anim_init_clock_timer1(){
		clock.stop();
		time1 = 0.0;
	}*/
	
	
	/*[NdL : 6]
	* sprites par defauts
	*/
	void anim_defaut(Joueur *j);	
	
	/*[NdL : 5]
	* mise à jour de la fenetre selon des animations "gif"
	*/
	void update_wind(Joueur *j_princ, Joueur* j_second, sf::RenderWindow* w);														/////
	
	/*[NdL : 5]
	* comparer la valeur du timer en seconde avec une valeur donner en argument,  si superieur alors true
	*/
	bool compareClk(Horloge& c, int sec);
	
	
	/*[NdL : 6]
	*selon le personnage, faire une animation attaque normal
	*/
	void animation_attq_n(Joueur *j_princ, Joueur* j_second, sf::RenderWindow* w);
	/*[NdL : 7]
	* animation yoda attaque normal 
	*/
	void anim_attq_n_yd(Joueur *j_princ, Joueur* j_second, sf::RenderWindow* w);
	
	/*[NdL : 11]
	* animation pour le moment où yoda active son sabre laser
	*/
	void anim_act_laser_yd(Joueur *j_princ, Joueur* j_second, sf::RenderWindow* w);
	
	
	
	/*[NdL : 19]
	*  animation pour activer l'arme yoda selon direction
	*/
	void anim_laserdroite_yd(Joueur *j_princ, Joueur* j_second, sf::RenderWindow* w, bool& b1, bool& b2, bool& b3,  bool& b4);																				////
	void anim_lasergauche_yd(Joueur *j_princ, Joueur* j_second, sf::RenderWindow* w, bool& b1, bool& b2, bool& b3,  bool& b4);		
																			////
	/*[NdL : 23]
	* animation boba fett attaque normal 
	*/
	void anim_attq_n_bf(Joueur *j_princ, Joueur* j_second, sf::RenderWindow* w);								
	/*[NdL : 15]
	* animation "gif" pour attaque normal de boba fett
	*/				
	void anim_gauche_attq_n_bf(Joueur *j_princ, Joueur* j_second, sf::RenderWindow* w);								
	void anim_droite_attq_n_bf(Joueur *j_princ, Joueur* j_second, sf::RenderWindow* w);											
	
	/*[NdL : 11]
	* animation pour le moment où dark vador active son sabre laser
	*/
	void anim_act_laser_dv(Joueur *j_princ, Joueur* j_second, sf::RenderWindow* w);						
	/*[NdL : 19]
	* animation pour activer l'arme drak vador selon direction
	*/
	void anim_laserdroite_dv(Joueur *j_princ, Joueur* j_second, sf::RenderWindow* w, bool& b1, bool& b2, bool& b3,  bool& b4);																				////
	void anim_lasergauche_dv(Joueur *j_princ, Joueur* j_second, sf::RenderWindow* w,  bool& b1, bool& b2, bool& b3,  bool& b4);																				////
	
	
	/*[NdL : 7]
	* animation dorak vador attaque normal 
	*/
	void anim_attq_n_dv(Joueur *j_princ, Joueur* j_second, sf::RenderWindow* w);
	
	/*[NdL : 4]
	* animation hansolo attaque normal 
	*/
	void anim_attq_n_hs(Joueur *j_princ);
		
	
	
	
	/*[NdL : 6]
	*	selon le personnage, faire une animation attaque special
	*/
	void animation_attq_s(Joueur *j_princ, Joueur* j_second, sf::RenderWindow* w);
	
	/*[NdL : 6]
	* animation han solo attaque special 
	*/
	void anim_attq_s_hs(Joueur *j_princ);
	/*[NdL : 6]
	* animation yoda attaque special 
	*/
	void anim_attq_s_yd(Joueur *j_princ);
	/*[NdL : 6]
	* animation boba fett attaque special 
	*/
	void anim_attq_s_bf(Joueur *j_princ);
	/*[NdL : 9]
	* animation dark vador attaque scpecial 
	*/
	void anim_attq_s_dv(Joueur *j_princ, Joueur* j_second, sf::RenderWindow* w);
	
	/*[NdL : 15]
	* animation "gif" pour attaque normal de boba fett
	*/	
	void anim_gauche_attq_s_dv(Joueur *j_princ, Joueur* j_second, sf::RenderWindow* w, bool& b1, bool& b2, bool& b3);
	void anim_droite_attq_s_dv(Joueur *j_princ, Joueur* j_second, sf::RenderWindow* w, bool& b1, bool& b2, bool& b3);
	
	
	
	
	/*[nombre de ligne : 6] 
	* determine le personnage qui doit realiser l'animation de deplacement
	* apppel la methode qui fait l'animation selon le personnage
	*/
	void animation_deplacemt(Joueur *j, dir_enum direction);
	
	/*[NdL : 10] 
	* pour yoda
	* apppel la methode qui fait l'animation selon la direction
	*/
	void anim_deplac_yd(Joueur *j, dir_enum direction);
	
	/*[NdL : 10] 
	* pour dark vador
	* apppel la methode qui fait l'animation selon la direction
	*/
	void anim_deplac_dv(Joueur *j, dir_enum direction);
	
	/*[NdL : 10] 
	* pour han solo
	* apppel la methode qui fait l'animation selon la direction
	*/
	void anim_deplac_hs(Joueur *j, dir_enum direction);
	
	/*[NdL : 10] 
	* pour boba fett
	* apppel la methode qui fait l'animation selon la direction
	*/
	void anim_deplac_bf(Joueur *j, dir_enum direction);
	
	
	
	/*
	* pour yoda
	* selon la direction 
	* faire le changement du sprite du personnage dans la fenetre par le sprite de l'animation qui doit etre afficher
	*/
	void yd_gauche(Joueur* j); 			//[NdL : 5] 
	void yd_droite(Joueur* j); 			//[NdL : 5]
	void yd_saut(Joueur* j); 			//[NdL : 5]
	void yd_bas(Joueur* j); 			//[NdL : 4]
	
	
	/*
	* pour dark vador
	* selon la direction 
	* faire le changement du sprite du personnage dans la fenetre par le sprite de l'animation qui doit etre afficher
	*/
	void dv_gauche(Joueur* j); 			//[NdL : 5]
	void dv_droite(Joueur* j);			//[NdL : 5]
	void dv_saut(Joueur* j);			//[NdL : 5]
	void dv_bas(Joueur* j);				//[NdL : 4]
	
	
	/*
	* pour han solo
	* selon la direction 
	* faire le changement du sprite du personnage dans la fenetre par le sprite de l'animation qui doit etre afficher
	*/
	void hs_gauche(Joueur* j);			//[NdL : 16]
	void hs_droite(Joueur* j);			//[NdL : 16]
	void hs_saut(Joueur* j);			//[NdL : 5]
	void hs_bas(Joueur* j);				//[NdL : 4]
	
	
	/*
	* pour boba fett
	* selon la direction 
	* faire le changement du sprite du personnage dans la fenetre par le sprite de l'animation qui doit etre afficher
	*/
	void bf_gauche(Joueur* j);			//[NdL : 14]
	void bf_droite(Joueur* j);			//[NdL : 14]
	void bf_saut(Joueur* j);			//[NdL : 5]
	void bf_bas(Joueur* j);				//[NdL : 4]
	
	
	void anim_missile(Joueur *j, sf::RenderWindow* w);/////////////////////////////:	///////////
	
};
