#include "Animation.hpp"

bool Animation::compareClk(Horloge& c, int sec){
	sf::Time e = c.getElapsedTime(); 
	if(e.asSeconds() >=  sec){
		return true;
	}
	return false;
}

void Animation::anim_defaut(Joueur *j){
	switch (j->get_perso_name()){
		case Yoda:		yd_bas(j); break;
		case HanSolo: 	hs_bas(j); break;
		case DarkVador: dv_bas(j); break;
		case BobaFett: 	bf_bas(j);	break;							//les sprites pour les animations bas sont les sprites par defaut. vu que on a d'abord coder les animations bas, auatnt les reutiliser
	}
}

void Animation::update_wind(Joueur* j_princ, Joueur* j_second, sf::RenderWindow* w){
	w->clear();
	m_game->drawBackground(*w);
	w->draw(j_second->get_sprite());
	w->draw(j_princ->get_sprite());
	w->display();
}

//anim attaq n
void Animation::animation_attq_n(Joueur *j_princ, Joueur* j_second, sf::RenderWindow* w){
	switch (j_princ->get_perso_name()){
		case Yoda:		anim_attq_n_yd(j_princ,j_second, w); break;
		case HanSolo: 	anim_attq_n_hs(j_princ); break;
		case DarkVador: anim_attq_n_dv(j_princ, j_second, w); break;
		case BobaFett: 	anim_attq_n_bf(j_princ, j_second, w);break;				
	}
}

//anim attaq s
void Animation::animation_attq_s(Joueur *j_princ, Joueur* j_second, sf::RenderWindow* w){
	switch (j_princ->get_perso_name()){
		case Yoda:		anim_attq_s_yd(j_princ); break;
		case HanSolo: 	anim_attq_s_hs(j_princ); break;
		case DarkVador: anim_attq_s_dv(j_princ, j_second, w); break;
		case BobaFett: 	anim_attq_s_bf(j_princ);break;				
	}
	update_wind(j_princ, j_second, w);
}

void Animation::anim_attq_s_hs(Joueur *j_princ){
	if(gauche_droite == true){
		j_princ->set_sprite(j_princ->get_hanS()->sprites_HS.s_atq_s_d);
	}
	if(gauche_droite == false){	
		j_princ->set_sprite(j_princ->get_hanS()->sprites_HS.s_atq_s_g);
	}
}

void Animation::anim_attq_s_yd(Joueur *j_princ){
	if(gauche_droite == true){
		j_princ->set_sprite(j_princ->get_yoda()->sprites_YD.s_atq_s_d);
	}
	if(gauche_droite == false){	
		j_princ->set_sprite(j_princ->get_yoda()->sprites_YD.s_atq_s_g);
	}
}
void Animation::anim_attq_s_bf(Joueur *j_princ){
	if(gauche_droite == true){
		j_princ->set_sprite(j_princ->get_boba()->sprites_BB.s_atq_s_d);
	}
	if(gauche_droite == false){	
		j_princ->set_sprite(j_princ->get_boba()->sprites_BB.s_atq_s_g);
	}
}

void Animation::anim_attq_s_dv(Joueur *j_princ, Joueur* j_second, sf::RenderWindow* w){
	bool b1(false), b2(false), b3(false);
	if(clock.isRunning() == false)
		clock.restart(true);
	while(clock.isRunning() == true){
		if(gauche_droite == false){
			anim_gauche_attq_s_dv(j_princ, j_second, w, b1, b2, b3);
		}else{
			anim_droite_attq_s_dv(j_princ, j_second, w,  b1, b2, b3);
		}
	}
}


void Animation::anim_gauche_attq_s_dv(Joueur *j_princ, Joueur* j_second, sf::RenderWindow* w, bool& b1, bool& b2, bool& b3){
	if(compareClk(clock, 0.2)&& b1==false){
		j_princ->set_sprite(j_princ->get_dark()->sprites_DV.s_atq_s_g);
		update_wind(j_princ, j_second, w);
		b1=true;
	}
	if(compareClk(clock, 0.4)&&b2==false){			
		j_princ->set_sprite(j_princ->get_dark()->sprites_DV.s_atq_s_g2);
		update_wind(j_princ, j_second, w);
		b2=true;
	}
	if(compareClk(clock, 0.6)&&b3==false){
		j_princ->set_sprite(j_princ->get_dark()->sprites_DV.s_atq_s_g3);
		update_wind(j_princ, j_second, w);
		b3=true;
	}
	if(compareClk(clock, 1)){
		clock.stop();
	}
}


void Animation::anim_droite_attq_s_dv(Joueur *j_princ, Joueur* j_second, sf::RenderWindow* w, bool& b1, bool& b2, bool& b3){
	if(compareClk(clock, 0.2)&& b1==false){
		b1=true;
		j_princ->set_sprite(j_princ->get_dark()->sprites_DV.s_atq_s_d);
		update_wind(j_princ, j_second, w);
	 }
	if(compareClk(clock, 0.4)&&b2==false){
		b2=true;
		j_princ->set_sprite(j_princ->get_dark()->sprites_DV.s_atq_s_d2);
		update_wind(j_princ, j_second, w);
	}
	if(compareClk(clock, 0.6)&&b3==false){
		b3=true;
		j_princ->set_sprite(j_princ->get_dark()->sprites_DV.s_atq_s_d3);
		update_wind(j_princ, j_second, w);
	}
	if(compareClk(clock, 1)){
		clock.stop();
	}
}




//animation atta n yoda
void Animation::anim_attq_n_yd(Joueur *j_princ, Joueur* j_second, sf::RenderWindow* w){
	if(j_princ->get_yoda()->get_sabre()==false){
		anim_act_laser_yd(j_princ, j_second, w);  
		j_princ->get_yoda()->set_sabre(true);
	}else{
		//j_princ->get_yoda()->set_sabre(false);
		if(gauche_droite == true)
			j_princ->set_sprite(j_princ->get_yoda()->sprites_YD.s_atq_n_d);
		if(gauche_droite == false)
			j_princ->set_sprite(j_princ->get_yoda()->sprites_YD.s_atq_n_g);
			update_wind(j_princ, j_second, w);
			/*if(clock.isRunning() == false)
				clock.restart(true);
			if(compareClk(clock, 1)){
				j_princ->set_sprite(j_princ->get_yoda()->sprites_YD.s_gauche);
				clock.stop();
			}
			*/
	}
}

void Animation::anim_act_laser_yd(Joueur *j_princ, Joueur* j_second, sf::RenderWindow* w){
	bool b1(false), b2(false), b3(false), b4(false);	
	if(clock.isRunning() == false)
		clock.restart(true);
	if(	j_princ->get_yoda()->get_sabre() != true){
		while(clock.isRunning() == true){
			if(gauche_droite == false){
				anim_lasergauche_yd(j_princ, j_second, w, b1, b2, b3, b4);
			}else{
				anim_laserdroite_yd(j_princ, j_second, w, b1, b2, b3, b4);
			}
		}
	}
}

void Animation::anim_lasergauche_yd(Joueur *j_princ, Joueur* j_second, sf::RenderWindow* w,  bool& b1, bool& b2, bool& b3, bool& b4){	
	if(compareClk(clock, 0)&& b1 == false){
		b1 = true;
		j_princ->set_sprite(j_princ->get_yoda()->sprites_YD.s_gauche_active_arme1);
		update_wind(j_princ, j_second, w);
	}else if(compareClk(clock, 0.3)&& b2 == false){
		b2 = true; 
		j_princ->set_sprite(j_princ->get_yoda()->sprites_YD.s_gauche_active_arme2);
		update_wind(j_princ, j_second, w);
	}else if(compareClk(clock, 0.6)&& b3== false){
		b3 = true;
		j_princ->set_sprite(j_princ->get_yoda()->sprites_YD.s_gauche_active_arme3);
		update_wind(j_princ, j_second, w);
	}else if(compareClk(clock, 0.8)&& b4== false){
		b4 = true;
		j_princ->set_sprite(j_princ->get_yoda()->sprites_YD.s_gauche_active_arme4);
		update_wind(j_princ, j_second, w);	
	}else if(compareClk(clock, 1)){
		clock.stop();
	}
}



void Animation::anim_laserdroite_yd(Joueur *j_princ, Joueur* j_second, sf::RenderWindow* w,  bool& b1, bool& b2, bool& b3, bool &b4){	
	if(compareClk(clock, 0)&& b1 == false){
		b1 = true;
		j_princ->set_sprite(j_princ->get_yoda()->sprites_YD.s_droite_active_arme1);
		update_wind(j_princ, j_second, w);
	}else if(compareClk(clock, 0.3)&& b2 == false){
		b2 = true; 
		j_princ->set_sprite(j_princ->get_yoda()->sprites_YD.s_droite_active_arme2);
		update_wind(j_princ, j_second, w);
	}else if(compareClk(clock, 0.6)&& b3== false){
		b3 = true;
		j_princ->set_sprite(j_princ->get_yoda()->sprites_YD.s_droite_active_arme3);
		update_wind(j_princ, j_second, w);
	}else if(compareClk(clock, 0.8)&& b4== false){
		b4 = true;
		j_princ->set_sprite(j_princ->get_yoda()->sprites_YD.s_droite_active_arme4);
		update_wind(j_princ, j_second, w);	
	}else if(compareClk(clock, 1)){
		clock.stop();
	}
}


//animation atta n han solo
void Animation::anim_attq_n_hs(Joueur *j_princ){
	if(gauche_droite == true){
		j_princ->set_sprite(j_princ->get_hanS()->sprites_HS.s_atq_n_d);
	}
	if(gauche_droite == false){	
		j_princ->set_sprite(j_princ->get_hanS()->sprites_HS.s_atq_n_g);
	}
}




//animation atta n dark vador
void Animation::anim_attq_n_dv(Joueur *j_princ, Joueur* j_second, sf::RenderWindow* w){
	if(j_princ->get_dark()->get_sabre()== false){
		anim_act_laser_dv(j_princ,j_second, w); 
		j_princ->get_dark()->set_sabre(true);
	}else{
		if(gauche_droite == true){
			j_princ->set_sprite(j_princ->get_dark()->sprites_DV.s_atq_n_d);
		}if(gauche_droite == false){
			j_princ->set_sprite(j_princ->get_dark()->sprites_DV.s_atq_n_g);
		}	
		//j_princ->get_dark()->set_sabre(false);
	}
}
	
void Animation::anim_act_laser_dv(Joueur *j_princ, Joueur* j_second, sf::RenderWindow* w){
	bool b1(false), b2(false), b3(false), b4(false);	
	if(clock.isRunning() == false)
		clock.restart(true);
	if(	j_princ->get_dark()->get_sabre() != true){
		while(clock.isRunning() == true){
			if(gauche_droite == false){
				anim_lasergauche_dv(j_princ, j_second, w, b1, b2, b3, b4);
			}else{
				anim_laserdroite_dv(j_princ, j_second, w,  b1, b2, b3, b4);
			}
		}
	}
}


void Animation::anim_lasergauche_dv(Joueur *j_princ, Joueur* j_second, sf::RenderWindow* w, bool& b1, bool& b2, bool& b3,  bool& b4){																		////
	if(compareClk(clock, 0)&& b1 == false){
		b1 = true;
		j_princ->set_sprite(j_princ->get_dark()->sprites_DV.s_gauche_active_arme1);
		update_wind(j_princ, j_second, w);
	}else if(compareClk(clock, 0.3)&& b2 == false){
		b2 = true;
		j_princ->set_sprite(j_princ->get_dark()->sprites_DV.s_gauche_active_arme2);
		update_wind(j_princ, j_second, w);
	}else if(compareClk(clock, 0.6)&& b3== false){
		b3=true;
		j_princ->set_sprite(j_princ->get_dark()->sprites_DV.s_gauche_active_arme3);
		update_wind(j_princ, j_second, w);
	}else if(compareClk(clock, 0.8)&& b4== false){
		b4=true;
		j_princ->set_sprite(j_princ->get_dark()->sprites_DV.s_gauche_active_arme4);
		update_wind(j_princ, j_second, w);
	}else if(compareClk(clock, 1)){
		clock.stop();
	}
}


void Animation::anim_laserdroite_dv(Joueur *j_princ, Joueur* j_second, sf::RenderWindow* w, bool& b1, bool& b2, bool& b3,  bool& b4){
	if(compareClk(clock, 0)&& b1 == false){
		b1 = true;
		j_princ->set_sprite(j_princ->get_dark()->sprites_DV.s_droite_active_arme1);
		update_wind(j_princ, j_second, w);
	}else if(compareClk(clock, 0.3)&& b2 == false){
		b2 = true;
		j_princ->set_sprite(j_princ->get_dark()->sprites_DV.s_droite_active_arme2);
		update_wind(j_princ, j_second, w);
	}else if(compareClk(clock, 0.6)&& b3== false){
		b3 = true;
		j_princ->set_sprite(j_princ->get_dark()->sprites_DV.s_droite_active_arme3);
		update_wind(j_princ, j_second, w);
	}else if(compareClk(clock, 0.8)&& b4== false){
		b4 = true;
		j_princ->set_sprite(j_princ->get_dark()->sprites_DV.s_droite_active_arme4);
		update_wind(j_princ, j_second, w);
	}else if(compareClk(clock, 1)){
		j_princ->set_sprite(j_princ->get_dark()->sprites_DV.s_droite);
		clock.stop();
	}
}



//animation atta n boba fett
void Animation::anim_attq_n_bf(Joueur *j_princ, Joueur* j_second, sf::RenderWindow* w){
	if(clock.isRunning() == false)
		clock.restart(true);
	while(clock.isRunning() == true){
		if(gauche_droite == false){
			anim_gauche_attq_n_bf(j_princ, j_second, w);
		}else{
			anim_droite_attq_n_bf(j_princ, j_second, w);
		}
	}
}


void Animation::anim_gauche_attq_n_bf(Joueur *j_princ, Joueur* j_second, sf::RenderWindow* w){
	if(compareClk(clock, 0.2)){
		j_princ->set_sprite(j_princ->get_boba()->sprites_BB.s_atq_n_g);
		update_wind(j_princ, j_second, w);
	}
	if(compareClk(clock, 0.4)){			
		j_princ->set_sprite(j_princ->get_boba()->sprites_BB.s_atq_n_g2);
		update_wind(j_princ, j_second, w);
	}
	if(compareClk(clock, 0.6)){
		j_princ->set_sprite(j_princ->get_boba()->sprites_BB.s_atq_n_g3);
		update_wind(j_princ, j_second, w);
	}
	if(compareClk(clock, 0.8)){
		clock.stop();
	}
}


void Animation::anim_droite_attq_n_bf(Joueur *j_princ, Joueur* j_second, sf::RenderWindow* w){
	if(compareClk(clock, 0.2)){
		j_princ->set_sprite(j_princ->get_boba()->sprites_BB.s_atq_n_d);
		update_wind(j_princ, j_second, w);
	 }
	if(compareClk(clock, 0.4)){
		j_princ->set_sprite(j_princ->get_boba()->sprites_BB.s_atq_n_d2);
		update_wind(j_princ, j_second, w);
	}
	if(compareClk(clock, 0.6)){
		j_princ->set_sprite(j_princ->get_boba()->sprites_BB.s_atq_n_d3);
		update_wind(j_princ, j_second, w);
	}
	if(compareClk(clock, 0.8)){
		clock.stop();
	}
}


//anim deplacer
void Animation::animation_deplacemt(Joueur *j, dir_enum direction){
	switch (j->get_perso_name()){
		case Yoda:		anim_deplac_yd(j, direction); break;
		case HanSolo: 	anim_deplac_hs(j, direction); break;
		case DarkVador: anim_deplac_dv(j, direction); break;
		case BobaFett: 	anim_deplac_bf(j, direction);break;				
	}
}

void Animation::anim_deplac_yd(Joueur *j, dir_enum direction){
	switch (direction){
			case Gauche:	yd_gauche(j);
							break;
			case Droite: 	yd_droite(j);
							break;
			case Haut: 		yd_saut(j);
							break;
			case Bas:		yd_bas(j);
							break;
	}
}

void Animation::anim_deplac_dv(Joueur *j, dir_enum direction){
	switch (direction){
			case Gauche:	dv_gauche(j);
							break;
			case Droite: 	dv_droite(j);
							break;
			case Haut: 		dv_saut(j);
							break;
			case Bas:		dv_bas(j);
							break;
	}
}

void Animation::anim_deplac_hs(Joueur *j, dir_enum direction){
	switch (direction){
			case Gauche:	hs_gauche(j);
							break;
			case Droite: 	hs_droite(j);
							break;
			case Haut: 		hs_saut(j);
							break;
			case Bas:		hs_bas(j);
							break;
	}
}


void Animation::anim_deplac_bf(Joueur* j, dir_enum direction){
	switch (direction){
			case Gauche:	bf_gauche(j);
							break;
			case Droite: 	bf_droite(j);
							break;
			case Haut: 		bf_saut(j);
							break;
			case Bas:		bf_bas(j);
							break;
	}
}




//animation_deplacemt yoda
void Animation::yd_gauche(Joueur* j){
	j->set_sprite(j->get_yoda()->sprites_YD.s_gauche);
	gauche_droite = false;
	if(j->get_yoda()->get_saut() == true)
		j->set_sprite(j->get_yoda()->sprites_YD.s_saut_g);
	j->get_yoda()->set_saut(false);
}
void Animation::yd_droite(Joueur* j){
	j->set_sprite(j->get_yoda()->sprites_YD.s_droite);
	gauche_droite = true;
	if(j->get_yoda()->get_saut() == true)
		j->set_sprite(j->get_yoda()->sprites_YD.s_saut_d);
	j->get_yoda()->set_saut(false);
}
void Animation::yd_saut(Joueur* j){
	j->get_yoda()->set_saut(true);
	if(gauche_droite == true)
		j->set_sprite(j->get_yoda()->sprites_YD.s_saut_d);
	if(gauche_droite == false)
		j->set_sprite(j->get_yoda()->sprites_YD.s_saut_g);
}
void Animation::yd_bas(Joueur* j){
	if(gauche_droite == true)
		j->set_sprite(j->get_yoda()->sprites_YD.s_droite);
	if(gauche_droite == false)
		j->set_sprite(j->get_yoda()->sprites_YD.s_gauche);
}




//animation_deplacemt dark vador
void Animation::dv_gauche(Joueur* j){
	j->set_sprite(j->get_dark()->sprites_DV.s_gauche);
	gauche_droite = false;
	if(j->get_dark()->get_saut() == true)
		j->set_sprite(j->get_dark()->sprites_DV.s_saut_g);
	j->get_dark()->set_saut(false);
}
void Animation::dv_droite(Joueur* j){
	j->set_sprite(j->get_dark()->sprites_DV.s_droite);
	gauche_droite = true;
	if(j->get_dark()->get_saut() == true)
		j->set_sprite(j->get_dark()->sprites_DV.s_saut_d);
	j->get_dark()->set_saut(false);
}
void Animation::dv_saut(Joueur* j){
	j->get_dark()->set_saut(true);  
	if(gauche_droite == true)
		j->set_sprite(j->get_dark()->sprites_DV.s_saut_d);
	if(gauche_droite == false)
		j->set_sprite(j->get_dark()->sprites_DV.s_saut_g);  
}
void Animation::dv_bas(Joueur* j){
	if(gauche_droite == true)
		j->set_sprite(j->get_dark()->sprites_DV.s_droite);
	if(gauche_droite == false)
		j->set_sprite(j->get_dark()->sprites_DV.s_gauche);
}




//animation_deplacemt han solo
void Animation::hs_gauche(Joueur* j){
	compt ++;
	if(	j->get_hanS()->get_saut() != true){
		if(compt>=2)
			j->set_sprite(j->get_hanS()->sprites_HS.s_gauche);
		if(compt >= 4)
			j->set_sprite(j->get_hanS()->sprites_HS.s_gauche2);
		if(compt>= 6)
			j->set_sprite(j->get_hanS()->sprites_HS.s_gauche3);
		if(compt >= 8)
			j->set_sprite(j->get_hanS()->sprites_HS.s_gauche4);
		if(compt >= 10) compt = 1;
	}
	/*
	if(clock.isRunning() == false) clock.restart();
	if(	j->get_hanS()->get_saut() != true){
		j->set_sprite(j->get_hanS()->sprites_HS.s_gauche);
		if((time1 - clock.getElapsedTime().asSeconds()) > 5){
			j->set_sprite(j->get_hanS()->sprites_HS.s_gauche2);
		}
		if((time1 - clock.getElapsedTime().asSeconds()) > 10){
			j->set_sprite(j->get_hanS()->sprites_HS.s_gauche3);
		}
		if((time1 - clock.getElapsedTime().asSeconds()) > 15){
			j->set_sprite(j->get_hanS()->sprites_HS.s_gauche3);	
		}
		if((time1 - clock.getElapsedTime().asSeconds()) > 30){
			j->set_sprite(j->get_hanS()->sprites_HS.s_gauche4);
			clock.restart();
		}
	}*/
	gauche_droite = false;
	if(j->get_hanS()->get_saut() == true)
		j->set_sprite(j->get_hanS()->sprites_HS.s_saut_g);
	j->get_hanS()->set_saut(false);
}
void Animation::hs_droite(Joueur* j){
	compt ++;
	if(	j->get_hanS()->get_saut() != true){
		if(compt>=2)
			j->set_sprite(j->get_hanS()->sprites_HS.s_droite);
		if(compt >= 4)
			j->set_sprite(j->get_hanS()->sprites_HS.s_droite2);
		if(compt>= 6)
			j->set_sprite(j->get_hanS()->sprites_HS.s_droite3);
		if(compt >= 8)
			j->set_sprite(j->get_hanS()->sprites_HS.s_droite4);
		if(compt >= 10) compt = 1;
	}
	gauche_droite = true;
	if(j->get_hanS()->get_saut() == true)
		j->set_sprite(j->get_hanS()->sprites_HS.s_saut_d);
	j->get_hanS()->set_saut(false);
}
void Animation::hs_saut(Joueur* j){
	j->get_hanS()->set_saut(true);
	if(gauche_droite == true)
		j->set_sprite(j->get_hanS()->sprites_HS.s_saut_d);
	if(gauche_droite == false)
		j->set_sprite(j->get_hanS()->sprites_HS.s_saut_g);
}
void Animation::hs_bas(Joueur* j){
	if(gauche_droite == true)
		j->set_sprite(j->get_hanS()->sprites_HS.s_poseface);
	if(gauche_droite == false)
		j->set_sprite(j->get_hanS()->sprites_HS.s_poseface);
}





//animation_deplacemt boba fett
void Animation::bf_gauche(Joueur* j){
	compt ++;
	if(	j->get_boba()->get_saut() != true){
		if(compt>=2)
			j->set_sprite(j->get_boba()->sprites_BB.s_gauche2);	
		if(compt >= 4)
			j->set_sprite(j->get_boba()->sprites_BB.s_gauche3);	
		if(compt>= 6)
			j->set_sprite(j->get_boba()->sprites_BB.s_gauche4);	
		if(compt >= 8) compt = 1;
	}
	gauche_droite = false;
	if(j->get_boba()->get_saut() == true)
		j->set_sprite(j->get_boba()->sprites_BB.s_saut_g2);
	j->get_boba()->set_saut(false);
}
void Animation::bf_droite(Joueur* j){
		compt++;
	if(	j->get_boba()->get_saut() != true){
		if(compt>=2)
			j->set_sprite(j->get_boba()->sprites_BB.s_droite2);	
		if(compt >= 3)
			j->set_sprite(j->get_boba()->sprites_BB.s_droite3);	
		if(compt>= 4)
			j->set_sprite(j->get_boba()->sprites_BB.s_droite4);	
		if(compt >= 5) compt = 2;
	}
	gauche_droite = true;
	if(j->get_boba()->get_saut() == true)
		j->set_sprite(j->get_boba()->sprites_BB.s_saut_d2);
	j->get_boba()->set_saut(false);
}
void Animation::bf_saut(Joueur* j){
	j->get_boba()->set_saut(true);
	if(gauche_droite == true)
		j->set_sprite(j->get_boba()->sprites_BB.s_saut_d);
	if(gauche_droite == false)
		j->set_sprite(j->get_boba()->sprites_BB.s_saut_g);
}
void Animation::bf_bas(Joueur* j){
	if(gauche_droite == true)
		j->set_sprite(j->get_boba()->sprites_BB.s_droite);
	if(gauche_droite == false)
		j->set_sprite(j->get_boba()->sprites_BB.s_gauche);
}


void Animation::anim_missile(Joueur *j,  sf::RenderWindow* w){
	list<Missile>::iterator iter;
	switch(j->get_perso_name()){
		case HanSolo: 	if(j->get_hanS()->get_list_m_tirer().size() != 0){
							for(iter = j->get_hanS()->get_list_m_tirer().begin(); iter != j->get_hanS()->get_list_m_tirer().end(); ++iter){
								w->draw((*iter).get_sprite_mssle());
							}
						} break;
		case BobaFett: 	if(j->get_boba()->get_list_m_tirer().size() != 0){
							for(iter = j->get_hanS()->get_list_m_tirer().begin(); iter != j->get_hanS()->get_list_m_tirer().end(); ++iter){
								w->draw((*iter).get_sprite_mssle());
							}
						} break;
		default : break;
	}
}

