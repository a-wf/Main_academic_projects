#include "Mapp.hpp"

Mapp::Mapp(){
	//Chargement des ressources graphiques
	//Chargement du background
	if (!backgroundTexture.loadFromFile("graphiques/StarWarsBienvenue.jpg")){
		std::cout << "Erreur durant le chargement de l'image de bienvenue." << std::endl;
	}
	else
	background.setTexture(backgroundTexture);
}
 
void Mapp::drawBackground(sf::RenderWindow &window){
	window.draw(background);
}

void Mapp::set_background(sf::String emplacemt_image,int l, int h){
	if (!backgroundTexture.loadFromFile(emplacemt_image, sf::IntRect(0,0,l, h))){
		std::cout << "Erreur durant le chargement de l'image de fond" << std::endl;
	}
	else
	background.setTextureRect(sf::IntRect(0,0,l, h));
	background.setTexture(backgroundTexture);
}

