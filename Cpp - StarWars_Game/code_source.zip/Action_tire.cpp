#include <cmath>
#include "Action_tire.hpp"

void Action_tire::set_stock_munition(){	
	if(list_m_tirer.size() == MUNITION){
		munition = false;
	}else if(list_m_tirer.size() < MUNITION ){
		munition = true;
	}
}
	
	
void Action_tire::gestion_missile_tirer(Pers& p1){
	list<Missile>::iterator iter;
	if(list_m_tirer.size() != 0){
		for(iter = list_m_tirer.begin(); iter != list_m_tirer.end(); ++iter){
			if(missile_touche_advers(p1, *iter,iter) == false)
			missile_continue_trajet(*iter,iter);
		}
	}
}

bool Action_tire::missile_touche_advers(Pers& p1, Missile& m, list<Missile>::iterator& iter){
	if(p1.get_centre().get_x() <= m.get_centre().get_x() && (((p1.get_centre().get_y()+(p1.get_h_taille()/2))>=(m.get_centre().get_y()-m.get_L()/2))&& ((p1.get_centre().get_y()-(p1.get_h_taille()/2))<=(m.get_centre().get_y()+m.get_L()/2)))){
			if((p1.get_centre().get_x() + (p1.get_l_taille()/2)) >= (m.get_centre().get_x() - (m.get_l()/2))){
				p1.set_degatsubi(m.get_deg());
				list_m_tirer.erase(iter);
				p1.set_centre(Centre(p1.get_centre().get_x()-30, p1.get_centre().get_y()));
				return true;
			}			
	}else if(p1.get_centre().get_x() >= m.get_centre().get_x()&&(((p1.get_centre().get_y()+(p1.get_h_taille()/2))>=(m.get_centre().get_y()-m.get_L()/2))&&((p1.get_centre().get_y()-(p1.get_h_taille()/2))<=(m.get_centre().get_y()+m.get_L()/2)))){
			if((p1.get_centre().get_x() - (p1.get_l_taille()/2)) <= (m.get_centre().get_x() + (m.get_l()/2))){
				p1.set_degatsubi(m.get_deg());
				list_m_tirer.erase(iter);
				p1.set_centre(Centre(p1.get_centre().get_x()-30, p1.get_centre().get_y()));
				return true;
			}
	}
	return false;
}
	
		
	
void Action_tire::missile_continue_trajet(Missile& m,list<Missile>::iterator& iter){
		if(m.get_dir()==true){
			if(abs(m.get_centre().get_x() - m.get_p_ini().get_x()) >= distance_tire){
				list_m_tirer.erase(iter);
				return;
			}
			if(m.get_name().compare("missile_laser")== 0){
				m.get_centre().set_x(m.get_centre().get_x()+30);
				m.update_sprite_missile();
			}else if(m.get_name().compare("missile_flamme")== 0){
				m.get_centre().set_x(m.get_centre().get_x()+20);
				m.update_sprite_missile();
			}
		}else if(m.get_dir()==false){
				if(abs(m.get_centre().get_x() - m.get_p_ini().get_x()) >= distance_tire){
					list_m_tirer.erase(iter);
					return;
				}
				if(m.get_name().compare("missile_laser")== 0){
					m.get_centre().set_x(m.get_centre().get_x()-30);
					m.update_sprite_missile();
				}else if(m.get_name().compare("missile_flamme")== 0){
					m.get_centre().set_x(m.get_centre().get_x()-20);
					m.update_sprite_missile();
				}
		}
}
