#include "Hpp_Sources.hpp"

int main(){
	//Testgame tg;
	//tg.bienvenue();
	Game game;
}
