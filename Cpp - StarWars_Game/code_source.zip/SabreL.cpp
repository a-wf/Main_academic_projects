#include "SabreL.hpp"

void SabreL::set_sabre(bool b){
	s_lame = b;
}

void SabreL::action_atq_n(Pers &p1){
	if(((p1.get_centre().get_x()+p1.get_l_taille()) <= centre.get_x()+longueur_lame)&&((p1.get_centre().get_y()+p1.get_h_taille()/2)>= centre.get_y())&&((p1.get_centre().get_y()-p1.get_h_taille()/2)<centre.get_y())){
		if((p1.get_centre().get_x()+p1.get_l_taille())>= centre.get_x()-longueur_lame){
			p1.set_degatsubi(degN);
			p1.set_centre(Centre(p1.get_centre().get_x()-25, p1.get_centre().get_y()));
		}
	}else if ((p1.get_centre().get_x() >= (centre.get_x()+l_taille))&&((p1.get_centre().get_y()+p1.get_h_taille()/2)>= centre.get_y())&&((p1.get_centre().get_y()-p1.get_h_taille()/2)<centre.get_y())){
		if((p1.get_centre().get_x()+5)<= (centre.get_x()+l_taille+longueur_lame)){
			p1.set_degatsubi(degN);
			p1.set_centre(Centre(p1.get_centre().get_x()+25, p1.get_centre().get_y()));
		}
	}
}
