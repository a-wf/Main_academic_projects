#include "Pers.hpp"


bool Pers::deplacer(dir_enum dir){
	if(dir == Gauche){
			this->set_centre(Centre (centre.get_x()-15,centre.get_y()));  //deplacer vers la gauche
			gauche_droite = false;
	}else if(dir == Droite){
		this->set_centre(Centre (centre.get_x()+15,centre.get_y()));  //deplacer vers la droite
		gauche_droite = true;
	}else if(dir == Haut){
		this->set_centre(Centre (centre.get_x(),centre.get_y()-15));  //sauter
		b_saut = true;
	}else if(dir == Bas){
		this->set_centre(Centre (centre.get_x(),centre.get_y()+15));  //descendre
		b_saut = false;
	}else{
		return false;
	}
	return true;
}


/*
void Pers::utilise_obj(Objet obj){
	obj.action();
}	
*/

/*void Pers::mouvement(Direction dir) {
	switch (dir) {
		case Droite : 	this.get_centre.set_x(this.get_centre().get_x()++);break;
		case Gauche : 	this.get_centre.set_x(this.get_centre().get_x()--);break;
		case Haut 	:	this.get_centre.set_y(this.get_centre().get_y()--);break
	}
}*/

/*
bool Pers::prendre_objet(Objet obj){
	posseder_objet = true; 
	
	switch (name) {
		case Yoda :		obj.get_centre().set_y(obj.get_centre().get_y()+h_taille/4*3);
							break;
							
		case DarkVador : obj.get_centre().set_y(obj.get_centre().get_y()+h_taille/3);
							break; 
						
		case BobaFett : 	obj.get_centre().set_y(obj.get_centre().get_y()+h_taille/3);
							break; 
							
		case HanSolo : 	obj.get_centre().set_y(obj.get_centre().get_y()+h_taille/5*3);
							break; 	
		default :           break;		
	}
	return posseder_objet;				
}
*/

/*
bool Pers::deplacer_rapide(dir_enum dir){
	if(dir == 1){
		this->set_centre(Centre (centre.get_x()-15,centre.get_y()));  //deplacer vers la gauche
	}else if(dir == 2){
		this->set_centre(Centre (centre.get_x()+15,centre.get_y()));  //deplacer vers la droite
	}
	if(posseder_objet == true){
		if(dir == 1){
			obj.get_centre().set_x(centre.get_x() - 15);  //deplacer vers la gauche
		}else if(dir == 2){
			obj.get_centre().set_x(centre.get_x() + 15);  //deplacer vers la droite
		}
	}else{
		return false;
	}
	return true;
}
*/
