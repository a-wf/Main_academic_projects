#pragma once 
#include "Sprites_pers.hpp"

class Sprites_Rebel : virtual public Sprites_pers{
private :
	// texture de l'image missile normal a charger
	sf::Texture t_misN;
	// texture de l'image missile special a charger
	sf::Texture t_misS;
 
public :
	//sprites des mouvements uniques à han solo, en public pour faciliter l'utilisation
	sf::Sprite s_gauche4;
	sf::Sprite s_gauche2;
	sf::Sprite s_gauche3;
	sf::Sprite s_droite4;
	sf::Sprite s_droite2;
	sf::Sprite s_droite3;
	sf::Sprite s_poseface;
	//sprites des missiles, en public pour faciliter l'utilisation
	sf::Sprite s_misN;
	sf::Sprite s_misSg;
	sf::Sprite s_misSd;
	
	//[NdL : 17] constructeur qui charge tous les sprites
	Sprites_Rebel(std::string emplacemt): Sprites_pers(emplacemt), s_gauche4(t_pers,sf::IntRect(984, 5, 94,163)), 
	s_gauche2(t_pers, sf::IntRect(856,5,89,163)), s_gauche3(t_pers, sf::IntRect(729, 5, 107, 163)), 
	s_droite4(t_pers, sf::IntRect(630,5,94, 163)),s_droite2(t_pers, sf::IntRect(392, 5, 89, 163)), 
	s_droite3(t_pers, sf::IntRect(508,5,108,161)), s_poseface(t_pers, sf::IntRect(1237,5,83,162))
	{
		s_gauche.setTexture(t_pers);
		s_droite.setTexture(t_pers);
		s_saut_g.setTexture(t_pers);
		s_saut_d.setTexture(t_pers);
		s_atq_s_g.setTexture(t_pers);
		s_atq_n_g.setTexture(t_pers);
		s_atq_n_d.setTexture(t_pers);
		s_atq_s_d.setTexture(t_pers);
		s_gauche.setTextureRect(sf::IntRect(1109,5,114,157));
		s_droite.setTextureRect(sf::IntRect(256,5,114,157));
		s_saut_d.setTextureRect(sf::IntRect(12, 5, 104,162));
		s_saut_g.setTextureRect(sf::IntRect(133,5,104, 162));
		s_atq_s_g.setTextureRect(sf::IntRect(98, 171, 92,163));
		s_atq_n_g.setTextureRect(sf::IntRect(98, 171, 92,163));
		s_atq_n_d.setTextureRect(sf::IntRect(6,171,92,163));
		s_atq_s_d.setTextureRect(sf::IntRect(6,171,92,163));
		missile_charge_sprites();
	}
	
	
	//[NdL : 12]  chargement des images sprites pour missiles
	void missile_charge_sprites(){
		if (!t_misN.loadFromFile("graphiques/Personnage_jeu/missile.png")){
			std::cout << "Erreur durant le chargement pour les sprites missilesN" << std::endl;
		}
		if (!t_misS.loadFromFile("graphiques/Personnage_jeu/MissileSpecial.png")){
			std::cout << "Erreur durant le chargement pour les sprites missilesS" << std::endl;
		}
		s_misN.setTexture(t_misN);
		s_misSd.setTexture(t_misS);
		s_misSg.setTexture(t_misS);
		s_misN.setTextureRect(sf::IntRect(8,88,159,30));
		s_misSd.setTextureRect(sf::IntRect(4,28,46,33));
		s_misSg.setTextureRect(sf::IntRect(58,28,46,33));
	}
	
	//[NdL: : 15]  modifie la position de tous les sprites avec le centre du personnage
	void set_centre_sprites(Centre c){
		s_gauche.setPosition(c.get_x(), c.get_y());	//animationfait
		s_droite.setPosition(c.get_x(), c.get_y());	//animationfait
		s_saut_g.setPosition(c.get_x(), c.get_y());	//animationfait
		s_saut_d.setPosition(c.get_x(), c.get_y()); //animationfait
		s_atq_s_g.setPosition(c.get_x(), c.get_y());
		s_atq_n_g.setPosition(c.get_x(), c.get_y());
		s_atq_n_d.setPosition(c.get_x(), c.get_y());
		s_atq_s_d.setPosition(c.get_x(), c.get_y());
		s_gauche4.setPosition(c.get_x(), c.get_y()); //animationfait
		s_gauche2.setPosition(c.get_x(), c.get_y()); //animationfait
		s_gauche3.setPosition(c.get_x(), c.get_y()); //animationfait
		s_droite4.setPosition(c.get_x(), c.get_y()); //animationfait
		s_droite2.setPosition(c.get_x(), c.get_y()); //animationfait
		s_droite3.setPosition(c.get_x(), c.get_y()); //animationfait
		s_poseface.setPosition(c.get_x(), c.get_y()); //animationfait
		//set_centre_sprites_missile(Centre(s_atq_s_g.getLocalBounds().height/2, s_atq_s_g.getLocalBounds().width/2));
	}
	
	void set_centre_sprites_missile(Centre c){
		s_misN.setPosition(c.get_x(), c.get_y());
		s_misSd.setPosition(c.get_x(), c.get_y());
		s_misSg.setPosition(c.get_x(), c.get_y());
	}
};
