#pragma once

#include <iostream>
#include <list>
#include <cmath>
#include "Perso_name.hpp"
#include "Centre.hpp"
#include "Horloge.hpp"
#include "Mapp.hpp"
#include "Sprites_pers.hpp"
#include "Sprites_Sith.hpp"
#include "Sprites_Rebel.hpp"
#include "Sprites_Jedi.hpp"
#include "Sprites_Empire.hpp"
#include "Missile.hpp"
#include "Modules_affichage.hpp"
//#include "Objet.hpp"
#include "Pers.hpp"
#include "Action_tire.hpp"
#include "SabreL.hpp"
#include "Tireur.hpp"
#include "Empire_sith.hpp"
#include "Empire_tireur.hpp"
#include "Rebel_jedi.hpp"
#include "Rebel_tireur.hpp"
#include "Joueur.hpp"
#include "Animation.hpp"
#include "Game.hpp"
#include "Testgame.hpp"

using namespace sf;
using namespace std;
