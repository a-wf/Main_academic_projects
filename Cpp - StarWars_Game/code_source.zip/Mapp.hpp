#pragma once
#include <iostream>
#include <SFML/Graphics.hpp>
class Mapp
{
	public:
	//[NdL : 5] constructeur par defaut
	Mapp();
	
	/*
	* [NdL : 1] dessine dans la fenetre window le background
	*/
	void drawBackground(sf::RenderWindow& window);
	
	/*
	* [NdL : 6] 
	* charger une image à partir de emplacemt_image,
	* regler le sprite et la texture avec la dimension de l'image qu'on connait deja
	*/
	void set_background(sf::String emplacemt_image, int l, int h);
	
	// renvoie sprite background
	sf::Sprite get_backG()const{return background;};
	private:

	//Background
	sf::Texture backgroundTexture;
	sf::Sprite background;
};

