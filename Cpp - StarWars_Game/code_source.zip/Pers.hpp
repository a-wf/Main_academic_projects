#pragma once
#include <iostream>
#include <SFML/Graphics.hpp>
#include "Centre.hpp"
#include "Objet.hpp"
#include "Perso_name.hpp"
#define HAUTEUR_SAUT 150

using namespace std;

class Pers {
	
protected : 
	P_name name;			//ettiquette pour determiner le personnage 
	Centre centre;			//position du personnage
	
	int degat_subi;			//degat subi durant un jeu, plus c'est haut, plus c'est facile de perdre
	//bool posseder_objet;  // si il possede un objet, alors 1  
	bool en_defense;	// si il est en garde, alors true
	bool atk_reussi;	//si le personnage reussit son attaque
	int l_taille;		// largeur du personnage
	int h_taille;		// hauteur du personnage
	//bool subi_laforce;	//toucher par la force,   					//à revoir
	
	int en_saut=0;		//la difference entre le sol et le personnage
	
	const int h_saut = HAUTEUR_SAUT;    //la difference max entre le sol et le personnage
	
	bool gauche_droite = false ;  //pour connaitre le deplacement gauche(false) ou droite(true)
	bool b_saut = false;	//si personnage saute, alors true

	
public : 
	//[nombre de ligne : 1]constructor avec idenficateur P_name, la position initiale, la hauteur et la largeur du personnage
	Pers( const P_name& name1, const Centre& centre1,  int h_taille1, int l_taille1): 
		h_taille(h_taille1), l_taille(l_taille1), degat_subi(0)/*,posseder_objet(false)*/, en_defense(false), atk_reussi(false)
		{/*subi_laforce = false;*/ name = name1;  centre = centre1;}
	//[nombre de ligne : 1]construct par default
	Pers(){};
	
	//[NdL : 1] renvoie les degats subi 
	virtual int get_degatsubi() const {return degat_subi;}
	//[NdL : 1]renvoie la largeur
 	virtual int get_l_taille() const { return l_taille;}
	//[NdL : 1]renvoie le hauteur
 	virtual int get_h_taille() const { return h_taille;}
	//[NdL : 1]renvoie le centre 
 	virtual Centre get_centre() const { return centre;}
	//[NdL : 1]renvoie l'idenficateur
 	virtual P_name get_name() const { return name;}
	//[NdL : 1]renvoie le statut défense ou attaque 
	virtual bool get_defensive() const { return en_defense;}
	//[NdL : 1]renvoie true ou false a propos de si le personnage subi ou pas la force
	//virtual bool get_subiF()const{ return subi_laforce;}
	//[NdL : 1]renvoie true ou false, si personnage saute ou pas
	virtual bool get_saut()const{ return b_saut;}
	//[NdL : 1] renvoie la distance de saut
	virtual int get_en_saut()const {return en_saut;} 
	//[NdL : 1] renvoie la direction gauche ou droite
	virtual bool get_g_d()const {return gauche_droite;} 
	
	//[NdL : 1] les methodes set 
	//virtual void set_subiF(bool b){ subi_laforce = b;}
	virtual void set_centre(const Centre& cen){ centre = cen; }
	virtual void set_degatsubi( int deg) { degat_subi = deg+degat_subi;}
	virtual void set_defense(bool b){ en_defense = b;}
	virtual void set_saut(bool s){ b_saut = s;}
	virtual void set_en_saut(){en_saut++;}  
	
	//[NdL : 1]reset la distance entre le sol et le personnage
	virtual void reset_saut(){en_saut=0;}
	//[NdL : 1]se mettre en position defense 
	virtual void defense(){ en_defense = true;}      
	//[NdL : 13] se deplacer gauche ou droite ou sauter ou descendre		
	virtual bool deplacer(dir_enum dir);  	 	
	//virtual bool deplacer_rapide(dir_enum dir);	
	
	/* 
	virtual bool prendre_objet(Objet obj);										
	virtual void jeter_objet(){ posseder_objet = false;}						
	virtual void utilise_obj(Objet obj);												
	virtual bool get_Pobjet() const { return posseder_objet;}
	virtual void set_Pobjet(bool b){ posseder_objet = b;}
	*/			
	
	//[NdL : 1] destructeur
	~Pers(){}				
};
