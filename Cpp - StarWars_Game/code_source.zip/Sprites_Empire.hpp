#pragma once 
#include "Sprites_pers.hpp"

class Sprites_Empire:  public Sprites_pers{
private :
	// texture de l'image missile normal  a charger
	sf::Texture t_misN;
	//pas de texture pour missile special car deja contenu dans image personnage
public :
	
	//sprites des mouvements uniques à boba fett, en public pour faciliter l'utilisation
	sf::Sprite s_gauche4;
	sf::Sprite s_gauche2;
	sf::Sprite s_gauche3;
	sf::Sprite s_droite4;
	sf::Sprite s_droite2;
	sf::Sprite s_droite3;

	sf::Sprite s_saut_g2;
	sf::Sprite s_saut_d2;
	sf::Sprite s_saut_g3;
	sf::Sprite s_saut_d3;
	
	sf::Sprite s_atqsaut_g;		//durant un saut, peut etre ne pas utiliser
	sf::Sprite s_atqsaut_d;		//durant un saut, peut etre ne pas utiliser
	
	sf::Sprite s_atq_n_g2;
	sf::Sprite s_atq_n_d2;
	sf::Sprite s_atq_n_g3;
	sf::Sprite s_atq_n_d3;
	
	//sprites des missiles, en public pour faciliter l'utilisation
	sf::Sprite s_misN;
	sf::Sprite s_misS;
	
	
	//[NdL : 17] constructeur qui charge tous les sprites
	Sprites_Empire(std::string emplacemt): Sprites_pers(emplacemt), s_droite2(t_pers, sf::IntRect(2, 73, 184,160)), 
	s_droite3(t_pers, sf::IntRect(190,66,144,167)), s_droite4(t_pers,sf::IntRect(350, 89, 148,149)), 
	s_gauche2(t_pers, sf::IntRect(1120,696,184,153)), s_gauche3(t_pers, sf::IntRect(972, 684, 144, 165)), 
	s_gauche4(t_pers, sf::IntRect(808,708,148, 146)),s_saut_d2(t_pers, sf::IntRect(714, 6, 156, 232)), 
	s_saut_g3(t_pers, sf::IntRect(884,6,168,232)), s_saut_g2(t_pers,sf::IntRect(436,624,156, 230)), 
	s_saut_d3(t_pers,sf::IntRect(255, 624, 165, 230)), s_atqsaut_g(t_pers, sf::IntRect(1085, 8, 219, 198)),s_atqsaut_d(t_pers,sf::IntRect(2, 626,219,198)), 
	s_atq_n_g2(t_pers,sf::IntRect(858,866, 194,167)), s_atq_n_g3(t_pers,sf::IntRect(545,866,228,167)), s_atq_n_d2(t_pers,sf::IntRect(256, 250,194,165)), 
	s_atq_n_d3(t_pers,sf::IntRect(532, 250,230,165))
	{	s_gauche.setTexture(t_pers);
		s_droite.setTexture(t_pers);
		s_saut_g.setTexture(t_pers);
		s_saut_d.setTexture(t_pers);
		s_atq_s_g.setTexture(t_pers);
		s_atq_n_g.setTexture(t_pers);
		s_atq_n_d.setTexture(t_pers);
		s_atq_s_d.setTexture(t_pers);
		s_gauche.setTextureRect(sf::IntRect(969,245,133,164));
		s_droite.setTextureRect(sf::IntRect(792,248,130,165));
		s_saut_g.setTextureRect(sf::IntRect(631,654,116, 199));
		s_saut_d.setTextureRect(sf::IntRect(558, 37, 115, 200));
		s_atq_s_g.setTextureRect(sf::IntRect(347,863,147,165));
		s_atq_n_g.setTextureRect(sf::IntRect(1102,867,173,164));
		s_atq_n_d.setTextureRect(sf::IntRect(33,251,171,162));
		s_atq_s_d.setTextureRect(sf::IntRect(20,450,148,165));
		missile_charge_sprites();
	}
	
	//[NdL : 7]  chargement des images sprites pour missiles
	void missile_charge_sprites(){
		if (!t_misN.loadFromFile("graphiques/Personnage_jeu/missile.png")){
			std::cout << "Erreur durant le chargement pour les sprites missilesN" << std::endl;
		}
		s_misN.setTexture(t_misN);
		s_misS.setTexture(t_pers);
		s_misN.setTextureRect(sf::IntRect(179,516,159,32));
		s_misS.setTextureRect(sf::IntRect(222,492,76,76));
	}
	
	//[NdL: : 24]  modifie la position de tous les sprites avec le centre du personnage
	void set_centre_sprites(Centre c){
		s_gauche.setPosition(c.get_x(), c.get_y());
		s_droite.setPosition(c.get_x(), c.get_y());
		s_saut_g.setPosition(c.get_x(), c.get_y());
		s_saut_d.setPosition(c.get_x(), c.get_y());
		s_atq_s_g.setPosition(c.get_x(), c.get_y());
		s_atq_n_g.setPosition(c.get_x()-(s_atq_n_g.getLocalBounds().width/2)-5, c.get_y());
		s_atq_n_d.setPosition(c.get_x(), c.get_y());
		s_atq_s_d.setPosition(c.get_x(), c.get_y());
		s_gauche4.setPosition(c.get_x(), c.get_y());
		s_gauche2.setPosition(c.get_x(), c.get_y());
		s_gauche3.setPosition(c.get_x(), c.get_y());
		s_droite4.setPosition(c.get_x(), c.get_y());
		s_droite2.setPosition(c.get_x(), c.get_y());
		s_droite3.setPosition(c.get_x(), c.get_y());
		s_saut_g2.setPosition(c.get_x(), c.get_y());
		s_saut_d2.setPosition(c.get_x(), c.get_y());
		s_saut_g3.setPosition(c.get_x(), c.get_y());
		s_saut_d3.setPosition(c.get_x(), c.get_y());
		s_atqsaut_g.setPosition(c.get_x(), c.get_y());
		s_atqsaut_d.setPosition(c.get_x(), c.get_y());
		s_atq_n_g2.setPosition(c.get_x()-(s_atq_n_g2.getLocalBounds().width/2)-10, c.get_y());
		s_atq_n_d2.setPosition(c.get_x(), c.get_y());
		s_atq_n_g3.setPosition(c.get_x()-(s_atq_n_g3.getLocalBounds().width/2)-15, c.get_y());
		s_atq_n_d3.setPosition(c.get_x(), c.get_y());
		//set_centre_sprites_missile(Centre(s_atq_s_g.getLocalBounds().height/2, s_atq_s_g.getLocalBounds().width/2));
	}
	
	void set_centre_sprites_missile(Centre c){
		s_misN.setPosition(c.get_x(), c.get_y());
		s_misS.setPosition(c.get_x(), c.get_y());
	}
};
