#include "Joueur.hpp"
Joueur::Joueur(P_name p,const std::string& name, bool aAIorHuman)
{	name_j=name;name_p=p;AIorHuman=aAIorHuman;
	if(name_j == "Joueur1"){
		switch (name_p) {
			case Yoda:		yoda = new Rebel_jedi (77, Yoda, Centre(850,350), 150, 75);;break;
			case HanSolo: 	hanS = new Rebel_tireur (300, HanSolo, Centre(850,350), 165, 80);;break;
			case DarkVador: darkV =new Empire_sith (134, DarkVador, Centre(850,350),150, 105); ;break;
			case BobaFett: 	boba = new Empire_tireur (300, BobaFett, Centre(850,350), 168, 105);;break;
		} 
	}
	if(name_j == "Joueur2"){
		switch (name_p) {
			case Yoda:		yoda = new Rebel_jedi (77, Yoda, Centre(250,350), 150, 75);;break;
			case HanSolo: 	hanS = new Rebel_tireur (300, HanSolo, Centre(250,350), 165, 80);;break;
			case DarkVador:	darkV =new Empire_sith (134, DarkVador, Centre(250,350),150, 105); ;break;
			case BobaFett: 	boba = new Empire_tireur (300, BobaFett, Centre(250,350), 168, 105);;break;
		} 
	}
	init_sprite();
}


void Joueur::init_sprite() {   
	if(name_j == "Joueur1"){
		switch (name_p) {
			case Yoda: affiche= yoda->sprites_YD.s_droite;break;
			case HanSolo: affiche = hanS->sprites_HS.s_droite;break;
			case DarkVador: affiche = darkV->sprites_DV.s_droite;break;
			case BobaFett: affiche = boba->sprites_BB.s_droite;break;
		} 
	}
	if(name_j == "Joueur2"){
		switch (name_p) {
			case Yoda: affiche= yoda->sprites_YD.s_gauche;break;
			case HanSolo: affiche = hanS->sprites_HS.s_gauche;break;
			case DarkVador: affiche = darkV->sprites_DV.s_gauche;break;
			case BobaFett: affiche = boba->sprites_BB.s_gauche;break;
		} 
	}
}

void Joueur::deplacemt(dir_enum direction) {  
	switch (name_p){
		case Yoda: 	yoda->deplacer(direction);
					yoda->sprites_YD.set_centre_sprites(yoda->get_centre());
					break;
		case DarkVador: 	darkV->deplacer(direction);
							darkV->sprites_DV.set_centre_sprites(darkV->get_centre());
							break;
		case HanSolo: 	hanS->deplacer(direction);
						hanS->sprites_HS.set_centre_sprites(hanS->get_centre());
						break;
		case BobaFett: 	boba->deplacer(direction);
						boba->sprites_BB.set_centre_sprites(boba->get_centre());
						break;
	}
}


void Joueur::attaq_n(Joueur *j){
	switch (name_p){
		case Yoda: 	yd_att_contre_jadv(j);
					yoda->sprites_YD.set_centre_sprites(yoda->get_centre());
					break;
		case DarkVador: 	dark_att_contre_jadv(j);
							darkV->sprites_DV.set_centre_sprites(darkV->get_centre());
							break;
		case HanSolo: 	hs_att_contre_jadv(j);
						hanS->sprites_HS.set_centre_sprites(hanS->get_centre());
						break;
		case BobaFett: 	bf_att_contre_jadv(j);
						boba->sprites_BB.set_centre_sprites(boba->get_centre());
						break;
	}
}

bool Joueur::sauter(int p_sol) { //
	if (this->get_sprite().getPosition().y > p_sol-150) {
		this->deplacemt(Haut);
		return true;
	}
	this->set_saut(false);
	return false;
}


void Joueur::attaq_s(Joueur *j){
	switch (name_p){
		case Yoda: 	yd_att_scontre_jadv(j);
					yoda->sprites_YD.set_centre_sprites(yoda->get_centre());
					break;
		case DarkVador: 	dark_att_scontre_jadv(j);
							darkV->sprites_DV.set_centre_sprites(darkV->get_centre());
							break;
		case HanSolo: 	hs_att_scontre_jadv(j);
						hanS->sprites_HS.set_centre_sprites(hanS->get_centre());
						break;
		case BobaFett: 	bf_att_scontre_jadv(j);
						boba->sprites_BB.set_centre_sprites(boba->get_centre());
						break;
	}
}



void Joueur::yd_att_contre_jadv(Joueur *j){
	switch (j->get_perso_name()){
		case Yoda: 	yoda->action_atq_n(*j->get_yoda());
					j->get_yoda()->sprites_YD.set_centre_sprites(j->get_yoda()->get_centre());
					break;
		case DarkVador: 	yoda->action_atq_n(*j->get_dark());
							j->get_dark()->sprites_DV.set_centre_sprites(j->get_dark()->get_centre());
							break;
		case HanSolo: 	yoda->action_atq_n(*j->get_hanS());
						j->get_hanS()->sprites_HS.set_centre_sprites(j->get_hanS()->get_centre());
						break;
		case BobaFett: 	yoda->action_atq_n(*j->get_boba());
						j->get_boba()->sprites_BB.set_centre_sprites(j->get_boba()->get_centre());
						break;
	}
}


void Joueur::dark_att_contre_jadv(Joueur *j){
	switch (j->get_perso_name()){
		case Yoda: 	darkV->action_atq_n(*j->get_yoda());
					j->get_yoda()->sprites_YD.set_centre_sprites(j->get_yoda()->get_centre());
					break;
		case DarkVador: 	darkV->action_atq_n(*j->get_dark());
							j->get_dark()->sprites_DV.set_centre_sprites(j->get_dark()->get_centre());
							break;
		case HanSolo: 	darkV->action_atq_n(*j->get_hanS());
						j->get_hanS()->sprites_HS.set_centre_sprites(j->get_hanS()->get_centre());
						break;
		case BobaFett: 	darkV->action_atq_n(*j->get_boba());
						j->get_boba()->sprites_BB.set_centre_sprites(j->get_boba()->get_centre());
						break;
	}
}


void Joueur::hs_att_contre_jadv(Joueur *j){
	switch (j->get_perso_name()){
		case Yoda: 	hanS->action_atq_n();
					j->get_yoda()->sprites_YD.set_centre_sprites(j->get_yoda()->get_centre());
					break;
		case DarkVador: 	hanS->action_atq_n();
							j->get_dark()->sprites_DV.set_centre_sprites(j->get_dark()->get_centre());
							break;
		case HanSolo: 	hanS->action_atq_n();
						j->get_hanS()->sprites_HS.set_centre_sprites(j->get_hanS()->get_centre());
						break;
		case BobaFett: 	hanS->action_atq_n();
						j->get_boba()->sprites_BB.set_centre_sprites(j->get_boba()->get_centre());
						break;
	}
}

void Joueur::bf_att_contre_jadv(Joueur *j){
	switch (j->get_perso_name()){
		case Yoda: 	boba->action_atq_n();
					j->get_yoda()->sprites_YD.set_centre_sprites(j->get_yoda()->get_centre());
					break;
		case DarkVador: 	boba->action_atq_n();
							j->get_dark()->sprites_DV.set_centre_sprites(j->get_dark()->get_centre());
							break;
		case HanSolo: 	boba->action_atq_n();
						j->get_hanS()->sprites_HS.set_centre_sprites(j->get_hanS()->get_centre());
						break;
		case BobaFett: 	boba->action_atq_n();
						j->get_boba()->sprites_BB.set_centre_sprites(j->get_boba()->get_centre());
						break;
	}
}



void Joueur::yd_att_scontre_jadv(Joueur *j){
	switch (j->get_perso_name()){
		case Yoda: 	yoda->action_atq_s(*j->get_yoda());
					j->get_yoda()->sprites_YD.set_centre_sprites(j->get_yoda()->get_centre());
					break;
		case DarkVador: 	yoda->action_atq_s(*j->get_dark());
							j->get_dark()->sprites_DV.set_centre_sprites(j->get_dark()->get_centre());
							break;
		case HanSolo: 	yoda->action_atq_s(*j->get_hanS());
						j->get_hanS()->sprites_HS.set_centre_sprites(j->get_hanS()->get_centre());
						break;
		case BobaFett: 	yoda->action_atq_s(*j->get_boba());
						j->get_boba()->sprites_BB.set_centre_sprites(j->get_boba()->get_centre());
						break;
	}
}


void Joueur::dark_att_scontre_jadv(Joueur *j){
	switch (j->get_perso_name()){
		case Yoda: 	darkV->action_atq_s(*j->get_yoda());
					j->get_yoda()->sprites_YD.set_centre_sprites(j->get_yoda()->get_centre());
					break;
		case DarkVador: 	darkV->action_atq_s(*j->get_dark());
							j->get_dark()->sprites_DV.set_centre_sprites(j->get_dark()->get_centre());
							break;
		case HanSolo: 	darkV->action_atq_s(*j->get_hanS());
						j->get_hanS()->sprites_HS.set_centre_sprites(j->get_hanS()->get_centre());
						break;
		case BobaFett: 	darkV->action_atq_s(*j->get_boba());
						j->get_boba()->sprites_BB.set_centre_sprites(j->get_boba()->get_centre());
						break;
	}
}


void Joueur::hs_att_scontre_jadv(Joueur *j){
	switch (j->get_perso_name()){
		case Yoda: 	hanS->action_atq_s();
					j->get_yoda()->sprites_YD.set_centre_sprites(j->get_yoda()->get_centre());
					break;
		case DarkVador: 	hanS->action_atq_s();
							j->get_dark()->sprites_DV.set_centre_sprites(j->get_dark()->get_centre());
							break;
		case HanSolo: 	hanS->action_atq_s();
						j->get_hanS()->sprites_HS.set_centre_sprites(j->get_hanS()->get_centre());
						break;
		case BobaFett: 	hanS->action_atq_s();
						j->get_boba()->sprites_BB.set_centre_sprites(j->get_boba()->get_centre());
						break;
	}
}

void Joueur::bf_att_scontre_jadv(Joueur *j){
	switch (j->get_perso_name()){
		case Yoda: 	boba->action_atq_s();
					j->get_yoda()->sprites_YD.set_centre_sprites(j->get_yoda()->get_centre());
					break;
		case DarkVador: 	boba->action_atq_s();
							j->get_dark()->sprites_DV.set_centre_sprites(j->get_dark()->get_centre());
							break;
		case HanSolo: 	boba->action_atq_s();
						j->get_hanS()->sprites_HS.set_centre_sprites(j->get_hanS()->get_centre());
						break;
		case BobaFett: 	boba->action_atq_s();
						j->get_boba()->sprites_BB.set_centre_sprites(j->get_boba()->get_centre());
						break;
	}
}




void Joueur::hs_gestion_missile(Joueur *j){
	switch (j->get_perso_name()){
		case Yoda: 	hanS->gestion_missile_tirer(*j->get_yoda());
					break;
		case DarkVador: 	hanS->gestion_missile_tirer(*j->get_dark());
							break;
		case HanSolo: 	hanS->gestion_missile_tirer(*j->get_hanS());
						break;
		case BobaFett: 	hanS->gestion_missile_tirer(*j->get_boba());
						break;
	}
}

void Joueur::bf_gestion_missile(Joueur *j){
	switch (j->get_perso_name()){
		case Yoda: 	boba->gestion_missile_tirer(*j->get_yoda());
					break;
		case DarkVador: 	boba->gestion_missile_tirer(*j->get_dark());
							break;
		case HanSolo: 	boba->gestion_missile_tirer(*j->get_hanS());
						break;
		case BobaFett: 	boba->gestion_missile_tirer(*j->get_boba());
						break;
	}
}

