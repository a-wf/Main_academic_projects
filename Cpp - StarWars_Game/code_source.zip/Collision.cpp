#pragma once
#include "Collision.hpp"


void Collision::gravite (Joueur* j,int y,int x) {
		if (!(j->get_en_saut())) {
			if (j->get_sprite().getPosition().y < y) {
				j->deplacemt(Bas);
				anim.animation_deplacemt(j,Bas);
			}
		}
}

bool Collision::hors_limite(Joueur* j,int lim_gauche,int lim_droite,int lim_bas) {
		if (j->get_sprite().getPosition().x < lim_gauche || j->get_sprite().getPosition().x > lim_droite) {
				j->deplacemt(Bas);
				anim.animation_deplacemt(j,Bas);
				return true;
		}
		if (j->get_sprite().getPosition().y > lim_bas+50) {
			j->deplacemt(Bas);
			anim.animation_deplacemt(j,Bas);
			return true;
		} 
		return false;
}
	
	

