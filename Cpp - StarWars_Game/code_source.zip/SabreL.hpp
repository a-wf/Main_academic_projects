#pragma once
#include "Pers.hpp"


class SabreL : public Pers {
protected : 
	bool s_lame = false;  // activation du sabre laser
	int longueur_lame;	//la longueur du sabre laser
	const int degN = 5;	// degat causer par le sabre
	const int distance_atqS = 200;	// distance de l'attaque special, la force
public : 
	//[nombre de ligne : 1]constructeur
	SabreL(int d, const P_name& name1, const Centre& centre1,  int h_taille1, int l_taille1): 
				Pers(name1, centre1, h_taille1, l_taille1), longueur_lame(d) { name = name1;  centre = centre1; }

	/*
	* [NdL : 11] 
	*	Attaque normal d'un manieur de sabre laser
	* 	parametre : type Pers p1, pour causer des degats a l'adversaire
	*/
	virtual void action_atq_n(Pers& p1);

	//[NdL : 1] renvoie le booleen s_lame
	virtual bool get_sabre()const { return s_lame;}
	//[NdL : 1] le booleen s_lame devient true si egal à false, et vice versa
	virtual void set_sabre(bool b);
	//[NdL : 1] renvoie la longueur de la lame
	virtual int get_longueur_lame()const {return longueur_lame;}
	//[NdL : 1]  destructeur 	
	~SabreL(){}
};
