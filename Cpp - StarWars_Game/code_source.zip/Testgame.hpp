#pragma once
#include <iostream>
#include <SFML/Graphics.hpp>
#include "Mapp.hpp"
#include "Horloge.hpp"
#include "Game.hpp"
#define MX_ECRAN_PC 500
#define MY_ECRAN_PC 150
#define H_INTRO 320
#define L_INTRO 620
#define H_INTRO1 624
#define L_INTRO2 998

class Testgame {
private:
	int hauteur;	//hauteur de la fenetre
	int largeur;	//largeur de la fenetre
	const std::string fname = "Super Smash Bros : Star Wars";  //titre de la fenetre 
	sf::RenderWindow window;	//fenetre
	Horloge clock;	//timer
public :

	//[NdL : 3] constructeur par defaut
	Testgame();	
	
	/*[NdL : 24]
	* fenetre de bienvenue 
	*/
	void bienvenue();
	/*[NdL : 5]
	* fenetre menu start
	*/
	void bienvenue2(Mapp& intro);
	
	/*[NdL : 4]
	* redemarrer le timer quand b égale a false
	*/
	void restartClk(Horloge& c, bool &b);
	
	/*[NdL : 5]
	* comparer la valeur du timer en seconde avec une valeur donner en argument, si superieur alors true
	*/
	bool compareClk(Horloge& c, int sec);
	
	/*[NdL : 5]
	* changer la dimension de la fenetre
	*/
	void change_dim(int h, int l);
	
	
	/*[NdL : 22]
	* methode qui fait afficher le bouton start
	* et qui capture l'evenement clique gauche de la souris sur start
	* et demarre le jeu
	*/
	void start();
};
