#pragma once

//identificateur  personnage
enum P_name {Yoda=1, DarkVador, BobaFett, HanSolo};

//identificateur objet
//enum O_name {Soin=1, Gun, Rob}; 

//identificateur direction
enum dir_enum {Gauche = 1, Droite, Haut, Bas};
