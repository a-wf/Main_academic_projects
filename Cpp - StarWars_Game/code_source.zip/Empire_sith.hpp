#pragma once 
#include "SabreL.hpp"
#include "Sprites_Sith.hpp"

class Empire_sith : public SabreL {
public : 
	//les sprites de dark vador,   mis en public pour faciliter l'utilisation, a mettre en private si necessaire
	Sprites_Sith sprites_DV;
	
	//[nombre de ligne : 1]constructeur
	Empire_sith(int d, const P_name& name1, const Centre& centre1, int h_taille1, int l_taille1):
		SabreL(d, name1, centre1, h_taille1, l_taille1), sprites_DV("graphiques/Personnage_jeu/darkvador22.png"){sprites_DV.set_centre_sprites(centre1);}
		
	/*
	* [NdL : 13] 
	* Attaque special d'un sith, la force avec eclair    
	* meme si en realité, dark vador ne peut pas lancer des eclairs cause de ses fausse mains
	* parametre : type Pers p1, pour causer des degats a l'adversaire et le repousser
	*/
	void action_atq_s(Pers &p1);
	//[NdL : 2] modifier le centre du personnage et le centre des sprite du personnage
	void set_centre(Centre c){
		this->centre = c;
		sprites_DV.set_centre_sprites(c);
	}
	
	//[NdL : 1]  destructeur 
	~Empire_sith(){}	
};
