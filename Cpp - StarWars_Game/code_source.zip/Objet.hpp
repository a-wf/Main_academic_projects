/*
#pragma once
#include <iostream>

#include "Centre.hpp"
#include "Perso_name.hpp"
#include "Pers.hpp"

using namespace std;

//class  non utiliser, donc pas commenter, de plus, c'est une class virtual qui ne possede pas de methode importante
class Objet {
	
private : 
	int taille_L;
	int taille_H;
	Centre centre;
	O_name name;
	
public :
	Objet(int l, int h, const Centre& cen, O_name name1): taille_L(l), taille_H(h), centre(cen), name(name1){}
	
	Centre get_centre()const{return centre;}
	int get_taille_L() const { return taille_L;}
	int get_taille_H() const { return taille_H;}
	O_name get_name() const { return name;}
	virtual void action(){};
};
*/
