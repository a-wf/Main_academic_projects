#pragma once
#include <iostream>
#include "Centre.hpp"
#include <SFML/Graphics.hpp>

class Missile {
	
private :
	
	string name;  	//nom du missile  tel que "flamme" ou "laser"
	Centre centre;	//position du missile
	int l;  //longueur
	int _L;	//Largeur
	int deg;	//degat causer par le missile
	Centre position_initial;	//la position initial
	bool direction;
	sf::Sprite sprite_missile;	//sprite du missile
	
	public : 
	//[NdL : 1]  constructeur 
	Missile (const Centre& cen, int ll, int _lL, int degg, const string& name1, sf::Sprite s_m, bool dir): name(name1), 
	centre(cen), l(ll), _L(_lL),deg(degg), position_initial(cen), sprite_missile(s_m), direction(dir){}
	
	//[NdL : 1]  les gets 
	Centre get_centre()const { return centre;}
	void set_centre(const Centre& cen){ centre = cen;}
	int get_l() const { return l;}
	int get_L() const { return _L;}
	Centre get_p_ini()const { return position_initial;}
	string get_name() const {return name;}
	int get_deg()const{ return deg;}
	sf::Sprite get_sprite_mssle()const{return sprite_missile;}
	bool get_dir()const{return direction;}
	
	//[NdL : 1] modifie le sprite et sa position
	void update_sprite_missile(){
		sprite_missile.setPosition(centre.get_x(), centre.get_y());
	}
};
