#include "Rebel_tireur.hpp"

void Rebel_tireur::action_atq_s(){
	Missile mg(Centre(centre.get_x()+l_taille/2, centre.get_y()), 46,33, 20, "missile_flamme", sprites_HS.s_misSg, gauche_droite);
	Missile md(Centre(centre.get_x()+l_taille/2, centre.get_y()), 46,33, 20, "missile_flamme", sprites_HS.s_misSd, gauche_droite);
	if(gauche_droite = false){
			list_m_tirer.push_back(mg);
	}else if(gauche_droite == false){
			list_m_tirer.push_back(md);
	}
}


void Rebel_tireur::action_atq_n(){
	Missile m(Centre(centre.get_x()+l_taille/2, centre.get_y()), L_MISSILE,30, 10, "missile_laser", sprites_HS.s_misN, gauche_droite);
	list_m_tirer.push_back(m);
}
