#include "Rebel_jedi.hpp"

void Rebel_jedi::action_atq_s(Pers &p1){
	if(((p1.get_centre().get_x()+p1.get_l_taille()) <= centre.get_x())&&((p1.get_centre().get_y()+p1.get_h_taille()/2)>= centre.get_y())&&((p1.get_centre().get_y()-p1.get_h_taille()/2)<centre.get_y())){
		if((p1.get_centre().get_x()+p1.get_l_taille())>= centre.get_x()-distance_atqS){
			p1.set_centre(Centre(p1.get_centre().get_x()-50, p1.get_centre().get_y()));
		}
	}else if ((p1.get_centre().get_x() >= (centre.get_x()+l_taille))&&((p1.get_centre().get_y()+p1.get_h_taille()/2)>= centre.get_y())&&((p1.get_centre().get_y()-p1.get_h_taille()/2)<centre.get_y())){
		if((p1.get_centre().get_x()+5)<= (centre.get_x()+l_taille+distance_atqS)){
			p1.set_centre(Centre(p1.get_centre().get_x()+50, p1.get_centre().get_y()));
		}
	}
}
