#pragma once
#include <iostream>
#include "Perso_name.hpp"
#include "Empire_sith.hpp"
#include "Empire_tireur.hpp"
#include "Rebel_jedi.hpp"
#include "Rebel_tireur.hpp"

using namespace std;

class Joueur {

private : 
	string name_j;		//nom du joueur    "joueur n°1"  ou 'joueur n°2"
	bool AIorHuman;   //True : AI   False : human
	Empire_tireur* boba = NULL;		//boba de class personnage Empire_tireur
	Empire_sith* darkV = NULL;		//dark vador de class personnage Empire_sith
	Rebel_tireur* hanS = NULL;		//han solo de class personnage Rebel_tireur
	Rebel_jedi* yoda = NULL;		//yoda vador de class personnage Rebel_jedi
	P_name name_p;			//identificateur pour le personnage choisi 
	bool en_saut;
	sf::Sprite affiche;		//sprite d'animation du personnage choisi à afficher
	
public :

	//[nombre de ligne 18 : constructeur qui initialise l'un des personnages selon l'identificateur personnage
	Joueur (P_name p,const std::string& name, bool aAIorHuman);
		
	//[NdL : 1] qui remplace l'ancien sprite animation du personnage par le sprite animation a afficher
	void set_sprite(sf::Sprite s){ affiche = s;}
	
	/*[NdL : 16] 
	* initialise les positions initiales es sprites personnage
	*/
	void init_sprite();
	
	/*[NdL : 14] 
	* qui gere les deplacement des personnages et les positions des sprites durant le deplacement
	*/
	void deplacemt(dir_enum direction);
	
	/*[NdL : 14] 
	* qui gere les attaques normales des personnages 
	*/
	void attaq_n(Joueur *j);
	/*[NdL : 14] 
	* qui gere les attaques specials des personnages
	*/
	void attaq_s(Joueur *j);//////////////////////////////
	
	void yd_att_contre_jadv(Joueur *j);//////////////////////////////
	
	void dark_att_contre_jadv(Joueur *j);//////////////////////////////
	
	void hs_att_contre_jadv(Joueur *j);//////////////////////////////
	
	void bf_att_contre_jadv(Joueur *j);//////////////////////////////
	void yd_att_scontre_jadv(Joueur *j);//////////////////////////////
	
	void dark_att_scontre_jadv(Joueur *j);//////////////////////////////
	
	void hs_att_scontre_jadv(Joueur *j);//////////////////////////////
	
	void bf_att_scontre_jadv(Joueur *j);//////////////////////////////
	
	void bf_gestion_missile(Joueur *j);
	void hs_gestion_missile(Joueur *j);
	
	
	
	
	
	bool sauter(int y); //
	void set_saut(bool b) {en_saut = b;} //
	
	
	//[NdL : 1] les gets
	bool get_en_saut() {return en_saut;} //
	string get_nameJoueur() const {return name_j;}
	P_name get_perso_name() const {return name_p;}
	bool get_AiHuman() const { return AIorHuman;}
	Empire_sith* get_dark(){ return darkV;}
	Empire_tireur* get_boba(){ return boba;}
	Rebel_jedi* get_yoda(){ return yoda;}
	Rebel_tireur* get_hanS(){return hanS;}
	sf::Sprite get_sprite()const {return affiche;}
	
	~Joueur(){
		switch (name_p){
			case Yoda: 	delete yoda;
						break;
			case DarkVador: 	delete darkV;
								break;
			case HanSolo: 	delete hanS;
							break;
			case BobaFett: 	delete boba;
							break;
			}
	}
};
