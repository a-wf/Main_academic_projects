#pragma once 
#include <iostream>
#include <SFML/Graphics.hpp>
#include "Centre.hpp"

class Sprites_pers {
protected :
	// texture de l'image personnage a charger
	sf::Texture t_pers;
public :
	
	
	//image decouper en plusieurs parties, ci dessous les sprites basiques du personnage, en public pour faciliter l'utilisation
	sf::Sprite s_gauche;
	sf::Sprite s_droite;
	sf::Sprite s_saut_g;
	sf::Sprite s_saut_d;
	sf::Sprite s_atq_s_g;
	sf::Sprite s_atq_n_g;
	sf::Sprite s_atq_n_d;
	sf::Sprite s_atq_s_d;
	
	//[NdL : 3]  constructeur avec en argument l'emplacement et titre de l'image a charger 
	Sprites_pers(std::string emplacemt){
		if (!t_pers.loadFromFile(emplacemt)){
			std::cout << "Erreur durant le chargement pour les sprites personnages" << std::endl;
		}
	}
	
	//methode virtual a voir dans les sous class
	virtual void set_centre_sprites(Centre c) = 0 ;
};
