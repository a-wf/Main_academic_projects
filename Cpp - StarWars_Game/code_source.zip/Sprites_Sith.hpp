#pragma once 
#include "Sprites_pers.hpp"

class Sprites_Sith : virtual public Sprites_pers{

public :

	//sprites des mouvements uniques à dark vador, en public pour faciliter l'utilisation
	sf::Sprite s_gauche_avec_arme;
	sf::Sprite s_droite_avec_arme;
	
	sf::Sprite s_gauche_active_arme1;
	sf::Sprite s_gauche_active_arme2;
	sf::Sprite s_gauche_active_arme3;
	sf::Sprite s_droite_active_arme1;
	sf::Sprite s_droite_active_arme2;
	sf::Sprite s_droite_active_arme3;
	sf::Sprite s_droite_active_arme4;
	sf::Sprite s_gauche_active_arme4;
	
	
	sf::Sprite s_atq_s_d2;
	sf::Sprite s_atq_s_g2;
	sf::Sprite s_atq_s_d3;
	sf::Sprite s_atq_s_g3;
	
	
	//sprites des eclaire, en public pour faciliter l'utilisation
	sf::Texture t_eclaire;
	sf::Sprite s_eclair1g;
	sf::Sprite s_eclair2g;
	sf::Sprite s_eclair1d;
	sf::Sprite s_eclair2d;
	
	//[NdL : 16] constructeur qui charge tous les sprites
	Sprites_Sith(std::string emplacemt): Sprites_pers(emplacemt), s_gauche_avec_arme(t_pers, sf::IntRect(302, 368, 179,140)), 
	s_droite_avec_arme(t_pers, sf::IntRect(609,9,184,145)), s_gauche_active_arme1(t_pers,sf::IntRect(850, 368, 106,136)), 
	s_gauche_active_arme2(t_pers, sf::IntRect(702,368,122,138)), s_gauche_active_arme3(t_pers, sf::IntRect(528, 370, 153, 140)), 
	s_droite_active_arme1(t_pers, sf::IntRect(134,11,108, 139)),s_droite_active_arme2(t_pers, sf::IntRect(266, 13, 124, 137)), 
	s_droite_active_arme3(t_pers, sf::IntRect(410,16,154,140)), s_atq_s_d2(t_pers, sf::IntRect(430, 179, 161, 169)),
	s_atq_s_d3(t_pers,sf::IntRect(807, 177,162,171)), s_atq_s_g2(t_pers,sf::IntRect(501,536, 158,165)), s_atq_s_g3(t_pers,sf::IntRect(125,531,159,170)), 
	s_gauche_active_arme4(t_pers, sf::IntRect(299,368,176,143)), s_droite_active_arme4(t_pers, sf::IntRect(611,11,182,146))
	{
		s_gauche.setTexture(t_pers);
		s_droite.setTexture(t_pers);
		s_saut_g.setTexture(t_pers);
		s_saut_d.setTexture(t_pers);
		s_atq_s_g.setTexture(t_pers);
		s_atq_n_g.setTexture(t_pers);
		s_atq_n_d.setTexture(t_pers);
		s_atq_s_d.setTexture(t_pers);
		s_gauche.setTextureRect(sf::IntRect(977,363,108,140));
		s_droite.setTextureRect(sf::IntRect(6,9,108,139));
		s_saut_g.setTextureRect(sf::IntRect(0,168,180, 172));
		s_saut_d.setTextureRect(sf::IntRect(208, 168, 182, 172));
		s_atq_s_g.setTextureRect(sf::IntRect(305,535,160,166));
		s_atq_n_g.setTextureRect(sf::IntRect(25,355,266,155));
		s_atq_n_d.setTextureRect(sf::IntRect(803,0,266,155));
		s_atq_s_d.setTextureRect(sf::IntRect(627,179,162,169));
		eclair_charge_sprites();
	}
	
	//[NdL: : 20]  modifie la position de tous les sprites avec le centre du personnage
	void set_centre_sprites(Centre c){
		s_gauche.setPosition(c.get_x(), c.get_y());
		s_droite.setPosition(c.get_x(), c.get_y());
		s_saut_g.setPosition(c.get_x(), c.get_y());
		s_saut_d.setPosition(c.get_x(), c.get_y());
		s_atq_s_g.setPosition(c.get_x(), c.get_y());
		s_atq_n_g.setPosition(c.get_x() - (s_atq_n_g.getLocalBounds().width/2), c.get_y());
		s_atq_n_d.setPosition(c.get_x(), c.get_y());
		s_atq_s_d.setPosition(c.get_x(), c.get_y());
		s_gauche_avec_arme.setPosition(c.get_x(), c.get_y());
		s_droite_avec_arme.setPosition(c.get_x(), c.get_y());
		s_gauche_active_arme1.setPosition(c.get_x(), c.get_y());
		s_gauche_active_arme2.setPosition(c.get_x()-17, c.get_y());
		s_gauche_active_arme3.setPosition(c.get_x()-55, c.get_y());
		s_droite_active_arme1.setPosition(c.get_x(), c.get_y());
		s_droite_active_arme2.setPosition(c.get_x(), c.get_y());
		s_droite_active_arme3.setPosition(c.get_x(), c.get_y());
		s_atq_s_d2.setPosition(c.get_x(), c.get_y());
		s_atq_s_g2.setPosition(c.get_x(), c.get_y());
		s_atq_s_d3.setPosition(c.get_x(), c.get_y());
		s_atq_s_g3.setPosition(c.get_x(), c.get_y());
		s_droite_active_arme4.setPosition(c.get_x(), c.get_y());
		s_gauche_active_arme4.setPosition(c.get_x()-73, c.get_y());		
		s_eclair1g.setPosition(c.get_x()-s_atq_s_g3.getLocalBounds().width, c.get_y()-s_atq_s_g3.getLocalBounds().height/2);
		s_eclair2g.setPosition(c.get_x()-s_atq_s_g3.getLocalBounds().width, c.get_y()-s_atq_s_g3.getLocalBounds().height/2);
		s_eclair1d.setPosition(c.get_x()+s_atq_s_g3.getLocalBounds().width, c.get_y()-s_atq_s_g3.getLocalBounds().height/2);
		s_eclair2d.setPosition(c.get_x()+s_atq_s_g3.getLocalBounds().width, c.get_y()-s_atq_s_g3.getLocalBounds().height/2);
	}
	
	
	//[NdL : 12]  chargement des images sprites pour eclaire
	void eclair_charge_sprites(){
		if (!t_eclaire.loadFromFile("graphiques/Personnage_jeu/eclaire.png")){
			std::cout << "Erreur durant le chargement pour les sprites eclaire" << std::endl;
		}
		s_eclair1g.setTexture(t_eclaire);
		s_eclair2g.setTexture(t_eclaire);
		s_eclair1g.setTextureRect(sf::IntRect(0,0,191,60));
		s_eclair2g.setTextureRect(sf::IntRect(4, 81, 191,73)); 
		s_eclair1d.setTexture(t_eclaire);
		s_eclair2d.setTexture(t_eclaire);
		s_eclair1d.setTextureRect(sf::IntRect(218,3,191,60));
		s_eclair2d.setTextureRect(sf::IntRect(215, 96, 191,53));
	}
	
};
