#pragma once 
#include <iostream>
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <map>
#include <unistd.h>
#include <ctime>

#include "Mapp.hpp"
#include "Modules_affichage.hpp"
#include "Perso_name.hpp"
#include "Joueur.hpp"
#include "Animation.hpp"
#include "Collision.hpp"
#include <thread>
#define H_Game_W 638
#define L_Game_W 1064
#define P_sol_foret_lava 380
#define p_sol_mario 440
#define limite_g 50
#define limite_d 900

using namespace sf;
using namespace std;

//idenficateur pour les arenes
enum enum_map {foret, lave, style_mario};

class Game {
private :
	int pos_sol;	// position du sol en fonction des différentes map.
	int hauteur; 	//hauteur de la fenetre du jeu apres start
	int largeur;	//largeur de la fenetre du jeu apres start	
	enum_map id_enum_map;		//identificateur des maps du jeu
	sf::RenderWindow window;	//la fenetre du jeu
	Joueur* j1;					//joueur 1
	Joueur* j2;					//joueur 2    qui est soit un robot AI, soit un joueur humain
	Collision collision;		// classe de gestion de collision;
	Mapp m_game;				//map du jeu, arene du jeu
	Modules_affichage modules;	//les modules d'affichages pour les choix
	Modules_affichage module_fin;
	Animation anim1;			//les animations réaliser par le joueur 1
	Animation anim2;			//les animations realiser par le joueur 2
	bool appui1;
	bool appui2;																				//////////////////////////
	
	
	bool bool_nb_joueur;	 	//false si 1joueur, true si deux joueurs
	bool bool_coter; 			//false si lumiere  true si obscure
	
	/*[nombre de ligne : 16]
	* display de la fenetre jeu, durant les choix 
	*/
	void g_display();		
	
	/*[NdL : 7]
	* gere la fermeture de la fenetre, à utiliser avec window.isOpen()
	*/
	void f_close();				

	/*[NdL : 29]
	* capture des cliques gauche pour les choix du nombre de joueur 
	* revoie true pour savoir si le joueur a fait son choix
	*/
	bool choix_nb_joueur();  
	
	/*[NdL : 22]
	* capture des cliques gauche pour les choix du coter
	* revoie true pour savoir si le joueur a fait son choix
	*/
	bool choix_cot(int i);
	
	/*[NdL : 9]
	* capture des cliques gauche pour les choix du personnage a utiliser
	* appel soit la fonction membre "fenetre_choixPL" et "creer_pers_selonChoixL", soit la fonction membre "fenetre_choixPO" et "creer_pers_selonChoixO"
	* parametre : int i, pour determiner quel joueur fait le choix
	* revoie true pour savoir si le joueur a fait son choix
	*/
	bool choix_perso(int i);
	
	/*[NdL : 8]
	* afficher les modules concernant le coter lumiere
	* parametre : int i, pour determiner quel joueur fait le choix
	*/
	void fenetre_choixPL(int i);
	
	/*[NdL : 8]
	* afficher les modules concernant le coter obscure
	* parametre : int i, pour determiner quel joueur fait le choix
	*/
	void fenetre_choixPO(int i);

	/*[NdL : 19]
	* capture des cliques gauche pour les choix du personnage coter lumiere
	* parametre : int i, pour determiner quel joueur fait le choix
	* revoie true pour savoir si le joueur a fait son choix
	*/
	bool creer_pers_selonChoixL(int i);
	
	/*[NdL : 19]
	* capture des cliques gauche pour les choix du personnage coter obscure
	* parametre : int i, pour determiner quel joueur fait le choix
	* revoie true pour savoir si le joueur a fait son choix
	*/
	bool creer_pers_selonChoixO(int i);
	
	//void creer_pers_pourAI();  //pas dispo pour le moment, c'est juste réaliser les choix coter, et personnage aleatoirement, mais comme les actions du AI est long a coder, nous ne sommes pas encore assez motiver pour le faire
	
	/*[NdL : 23]
	* choisi aleatoirement le map arène du jeu
	*/
	void choix_map_jeu();
	
																				
	/*[NdL : 15]
	* display de la fenetre durant les combats 
	*/
	void run_game();			
	
	/*[NdL : 1]
	* le sprite personnage a dessiner sur la fenetre selon le joueur 
	*/
	void affiche_perso(Joueur* j);
	
	
	/*[NdL : 18]
	* gestion des deplacements et les animations de deplacement des personnage du joueur avec les evenements clavier
	*/
	void gestion_j2_deplacmt();
	void gestion_j1_deplacmt();
	
	/*[NdL : 3]
	* gestion des attaques normales et les animations d'attaque des personnage du joueur avec les evenements clavier
	*/
	void gestion_attaque_normal_j1();				
	void gestion_attaque_normal_j2();
	
	/*[NdL : 3]
	* gestion des attaques normales et les animations d'attaque des personnage du joueur avec les evenements clavier
	*/
	void gestion_attaque_special_j1();		
	void gestion_attaque_special_j2();		
	
	/*[NdL : ??]
	* gestion du collision des personnage avec le sol
	*/
	bool gestion_sol(Joueur* j);
	
	/*[NdL : 4]
	* afficher le sprite par defaut du personnage quand le joueur relache un bouton clavier, ne marche pas, alors que c'est du copier coller du tuto sfml; on ne sait pas pourquoi
	*/
	void gestion_j2_sans_appuis();
	void gestion_j1_sans_appuis();
	
	void gestion_tout();
	void gestion_missile();///////////////////////////////////
	void afficher_degat_subi();//////////////////////
	int get_degat_subi_j(Joueur* j);//////////
	void recommencer_partie();
	void gagner_perdu();
	bool g_p_j(Joueur* j);
	//void proba_ejecter_j1(int k);
	//void proba_ejecter_j2(int k);
	int get_p_sol() {return pos_sol;}
	int get_p_sol(Joueur * j);
	void set_p_sol (int p_sol) {pos_sol = p_sol;}
	void gestion_priorite_joueur();
	
public:
	//[NdL : 7] constructeur par defaut
	Game();
	//[NdL : 1] destructeur par defaut
	~Game(){};
};
