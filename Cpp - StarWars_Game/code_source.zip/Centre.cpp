#include "Centre.hpp"

 Centre Centre::operator+ ( const Centre& c2){
	//cout<<"addition + centre"<<endl;
	x+c2.get_x();
	y+c2.get_y();

}

 Centre Centre::operator- ( const Centre& c2){
	//cout<<"soustraction - centre"<<endl;
	x-c2.get_x();
	y-c2.get_y();
}

 Centre Centre::operator* ( const Centre& c2){
	//cout<<"multiplication * centre"<<endl;
	x*c2.get_x();
	y*c2.get_y();	
}

 Centre Centre::operator/ ( const Centre& c2){
	//cout<<"division / centre"<<endl;
	x/c2.get_x();
	y/c2.get_y();
}

 Centre Centre::operator+ ( float r){
	//cout<<"addition + centre r"<<endl;
	x+r;
	y+r;
}

 Centre Centre::operator- ( float r){
	//cout<<"soustraction - centre r"<<endl;
	x-r;
	y-r;
}

 Centre Centre::operator* ( float r){
	//cout<<"multiplication * centre r"<<endl;
	x*r;
	y*r;
}

Centre Centre::operator/ ( float r){
	//cout<<"division / centre r"<<endl;
	x/r;
	y/r;
}