#pragma once
#include "Tireur.hpp"
#include "Sprites_Rebel.hpp"
class Rebel_tireur : public Tireur {

public :
	//les sprites de han solo,   mis en public pour faciliter l'utilisation, a mettre en private si necessaire
	Sprites_Rebel sprites_HS;
	
	//[nombre de ligne : 1]constructeur
	Rebel_tireur(int distancetire, const P_name& name1, const Centre& centre1,  int h_taille1, int l_taille1):
		Tireur(distancetire, name1, centre1, h_taille1, l_taille1), sprites_HS("graphiques/Personnage_jeu/HanSolo13.png"){sprites_HS.set_centre_sprites(centre1);}
		
	/*
	* [NdL : 7] 
	*	Attaque special d'un tireur, tirer des gros missiles
	* 	il n'y a pas d'argument Pers adversaire car les degat sont gerer par la classe missile
	*/
	void action_atq_s();
	
	/*
	* [NdL : 2] 
	*	Attaque normal d'un tireur, tirer des laser, a chaque appel increment la liste des missiles
	* 	il n'y a pas d'argument Pers adversaire car les degat sont gerer par la classe missile
	*/
	void action_atq_n();
	
	//[NdL : 2] modifier le centre du personnage et le centre des sprite du personnage
	void set_centre(Centre c){
		this->centre = c;
		sprites_HS.set_centre_sprites(c);
	}
	
	//[NdL : 1]  destructeur 
	~Rebel_tireur(){}
};
