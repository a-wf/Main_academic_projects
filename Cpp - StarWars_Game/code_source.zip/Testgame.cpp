#include "Testgame.hpp"

Testgame::Testgame(): hauteur(H_INTRO), largeur(L_INTRO), window(sf::VideoMode(largeur, hauteur), fname), clock(){
		//Limite les fps à 60 images / seconde
		window.setFramerateLimit(60);
		//On active la synchro verticale
		window.setVerticalSyncEnabled(true);
		window.setPosition(sf::Vector2i(MX_ECRAN_PC, MY_ECRAN_PC));
}

void Testgame::bienvenue(){
		Mapp intro;
		bool b = false;
		bool b2 = true;
		while (window.isOpen()){
			// on inspecte tous les évènements de la fenêtre qui ont été émis depuis la précédente itération
			sf::Event event;
			while (window.pollEvent(event)){
				// évènement "fermeture demandée" : on ferme la fenêtre
				if (event.type == sf::Event::Closed)
					window.close();
			}
			window.clear();
			intro.drawBackground(window);
			restartClk(clock, b);  
			if(compareClk(clock, 2)&& b2 == true){
				bienvenue2(intro);
				b2 = false;
			}
			if(compareClk(clock, 3)){
				start();
				clock.~Horloge();
			}
			window.display();
		}
}

void Testgame::bienvenue2(Mapp& intro){
	window.clear();
	window.setPosition(sf::Vector2i(MX_ECRAN_PC-MX_ECRAN_PC/2, MY_ECRAN_PC-MY_ECRAN_PC/2));
	change_dim(H_INTRO1,L_INTRO2);
	intro.set_background("graphiques/StarWars_bienvenueBIS.jpg",625, 334);
	intro.drawBackground(window);
}


void Testgame::restartClk(Horloge& c, bool& b){
	if(b ==false){
	c.restart(true);  
	b = true;
	}
}

bool Testgame::compareClk(Horloge& c, int sec){
	sf::Time e = c.getElapsedTime(); 
	if(e.asSeconds() >=  sec){
		return true;
	}
	return false;
}


void Testgame::change_dim(int h, int l){
	hauteur = h;
	largeur = l;
	window.setSize(sf::Vector2u(largeur, hauteur));
}

void Testgame::start(){
	sf::Texture im_start;
	sf::Sprite bt_start;
	if (!im_start.loadFromFile("graphiques/start.png"))
	{
		std::cout << "Erreur durant le chargement de bouton start." << std::endl;
	}
	else{
	bt_start.setTexture(im_start);
	bt_start.setPosition(265.0,250.0);
	window.draw(bt_start);
	}
	/*les coordonnées int ci desous, sont determiner par des tests d'executions, 
	 * remarquons qu'il n'y a aucun rapport avec la position de bt_start et sa dimension
	 * ainsi ce n'est pas très précis, et si on change la dimension de la fenetre, le bouton start ne marchera plus
	 */
	if(sf::Mouse::isButtonPressed(sf::Mouse::Left)){  
		if(sf::Mouse::getPosition(window).x<587&&sf::Mouse::getPosition(window).x>431
		&&sf::Mouse::getPosition(window).y<568&& sf::Mouse::getPosition(window).y>537){
			window.close();
			Game game;
		}
	}
}
