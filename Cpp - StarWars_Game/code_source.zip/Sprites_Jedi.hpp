#pragma once 
#include "Sprites_pers.hpp"

class Sprites_Jedi : virtual public Sprites_pers{

public :

	//sprites des mouvements uniques à yoda, en public pour faciliter l'utilisation
	sf::Sprite s_gauche_avec_arme;
	sf::Sprite s_droite_avec_arme;
	sf::Sprite s_gauche_active_arme1;
	sf::Sprite s_gauche_active_arme2;
	sf::Sprite s_gauche_active_arme3;
	sf::Sprite s_droite_active_arme1;
	sf::Sprite s_droite_active_arme2;
	sf::Sprite s_droite_active_arme3;
	sf::Sprite s_droite_active_arme4;
	sf::Sprite s_gauche_active_arme4;
	
	//[NdL : 16] constructeur qui charge tous les sprites
	Sprites_Jedi(std::string emplacemt): Sprites_pers(emplacemt), s_gauche_avec_arme(t_pers, sf::IntRect(395, 118, 127,140)), 
	s_droite_avec_arme(t_pers, sf::IntRect(327,261,194,126)), s_gauche_active_arme1(t_pers,sf::IntRect(7, 140, 102,120)), 
	s_gauche_active_arme2(t_pers, sf::IntRect(134,138,104,120)), s_gauche_active_arme3(t_pers, sf::IntRect(262, 138, 110, 120)), 
	s_droite_active_arme1(t_pers, sf::IntRect(418,398,102, 120)),s_droite_active_arme2(t_pers, sf::IntRect(290, 396, 102, 120)), 
	s_droite_active_arme3(t_pers, sf::IntRect(155,396,102,120)), s_gauche_active_arme4(t_pers, sf::IntRect(396,128,130,135)), s_droite_active_arme4(t_pers, sf::IntRect(1,396,137,137))
	{
		s_gauche.setTexture(t_pers);
		s_droite.setTexture(t_pers);
		s_saut_g.setTexture(t_pers);
		s_saut_d.setTexture(t_pers);
		s_atq_s_g.setTexture(t_pers);
		s_atq_n_g.setTexture(t_pers);
		s_atq_n_d.setTexture(t_pers);
		s_atq_s_d.setTexture(t_pers);
		s_gauche.setTextureRect(sf::IntRect(210,264,103,118));
		s_droite.setTextureRect(sf::IntRect(214,6,103,118));
		s_saut_g.setTextureRect(sf::IntRect(404,6,112,107));
		s_saut_d.setTextureRect(sf::IntRect(5,269,112,107));
		s_atq_s_g.setTextureRect(sf::IntRect(404,6,112,107));
		s_atq_n_g.setTextureRect(sf::IntRect(0,8,194,126));
		s_atq_n_d.setTextureRect(sf::IntRect(326,261,194,126));
		s_atq_s_d.setTextureRect(sf::IntRect(5,269,112,107));
	}
	
	//[NdL: : 16]  modifie la position de tous les sprites avec le centre du personnage
	void set_centre_sprites(Centre c){
		s_gauche.setPosition(c.get_x(), c.get_y());
		s_droite.setPosition(c.get_x(), c.get_y());
		s_saut_g.setPosition(c.get_x(), c.get_y());
		s_saut_d.setPosition(c.get_x(), c.get_y());
		s_atq_s_g.setPosition(c.get_x(), c.get_y());
		s_atq_n_g.setPosition(c.get_x() - (s_atq_n_g.getLocalBounds().width/2), c.get_y());
		s_atq_n_d.setPosition(c.get_x(), c.get_y());
		s_atq_s_d.setPosition(c.get_x(), c.get_y());
		s_gauche_avec_arme.setPosition(c.get_x(), c.get_y());
		s_droite_avec_arme.setPosition(c.get_x(), c.get_y());
		s_gauche_active_arme1.setPosition(c.get_x(), c.get_y());
		s_gauche_active_arme2.setPosition(c.get_x(), c.get_y());
		s_gauche_active_arme3.setPosition(c.get_x()-37, c.get_y());
		s_droite_active_arme1.setPosition(c.get_x(), c.get_y());
		s_droite_active_arme2.setPosition(c.get_x(), c.get_y());
		s_droite_active_arme3.setPosition(c.get_x(), c.get_y());
		s_droite_active_arme4.setPosition(c.get_x(), c.get_y());
		s_gauche_active_arme4.setPosition(c.get_x()-51, c.get_y());
	}
		
};
